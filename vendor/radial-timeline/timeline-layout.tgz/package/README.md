# @radial-timeline/timeline-layout

Headless, deterministic polar geometry: `layout(document, config) → LayoutTree`.
Pure and framework-free, forever (ENGINEERING.md §4) — no DOM, no React, no
CSS, no `Date.now`/`Math.random`, no I/O. Same input always produces the same
output; this is a linted and tested property, not just a convention.

## Public API (`src/index.ts`)

- **Layout entry point**: `layout(document: LayoutDocument, config: LayoutConfig) → LayoutTree`.
- **Types**: `LayoutDocument`, `LayoutScene`, `LayoutConfig`,
  `TimelineArrangement`, `LayoutTree`, `ResolvedLayout`, `ActWedge`,
  `ScenePlacement`, `VoidCell`, `SceneAnchor`, `AnchorQuadrant`,
  `ArcAnchorInput`, `SubplotRing`.
- **Arrangement**: `LayoutConfig.arrangement` is required and explicit.
  `'narrative'` (manuscript order) is the only value implemented;
  `'chronologue'` is reserved and throws. There is no default, so a caller who
  wants a chronological wheel finds out here instead of by misreading a
  manuscript-order one.
- **Void cells**: `LayoutTree.voids` — one `VoidCell` per (act, ring, slot) a
  subplot does not occupy, ordered act, then ring, then slot. In `'narrative'`
  every ring shares its act's manuscript-order slot sequence, so the empty
  cells are what make a subplot's absence legible and keep slot 0 the act's
  first scene on every ring (`ScenePlacement.slot`). An act with no scenes
  yields one full-act cell per ring, at `slot: -1`.
- **Ordering**: `orderedScenes(document)` — scene items in manuscript order
  (`order`, ties by `id`), the one ordering the painter, the geometry and
  keyboard navigation all agree on.
- **Rings**: `subplotRings(document)` — subplots paired with their ring index,
  in ring order (main throughline outermost, then busiest first — see
  `subplots.ts`); `subplotsOf(scene)` and `DEFAULT_SUBPLOT` for the
  main-throughline fallback. `layout()` builds its ring stack from exactly
  this, so a legend built on it can never point at the wrong ring.
- **Callout anchors**: `arcAnchor(input) → SceneAnchor`,
  `anchorQuadrant(angle)` and `oppositeHalf(quadrant) → FrameHalf` — where a
  hover/selection panel should point, which quarter of the wheel it points
  into, and which half of the frame a full-height panel should therefore take.
  Every `ScenePlacement` carries its `anchor`, so the React layer positions
  callouts without doing polar math.
- **Canvas**: `frameRadius(input)` — the square viewBox, derived tightly from
  the rim plus the act-label band, never configured. `layout()` calls it, so
  the wheel fills its frame at the plugin's proportion (95.75%) for every
  manuscript. `FrameRadiusInput` is exported for callers that want the number
  without a whole tree.
- **Act labels**: `actLabelArc(input) → ActLabelArc`,
  `actLabelTextExtentDegrees(label, fontSize, radius)` and
  `ACT_LABEL_ARC_DEGREES` — an act's label terminates at that act's START
  boundary (act 1 at 12 o'clock), on a fixed-length arc outside the rim.
  `ActWedge.labelAnchorAtPathEnd` tells the painter which end of the emitted
  path carries the boundary, and `ActWedge.labelTextExtentDegrees` how far the
  glyphs run back from it. Both come from one decision inside `actLabels.ts` —
  see the boundary-anchoring invariant there and in `DEVIATIONS.md`.
- **Arc-text ink**: `arcTextOutwardInk(fontSize, ratio)`,
  `arcTextInwardInk(fontSize, ratio)` and
  `arcTextFlipRadiusOffset(fontSize, outwardRatio, inwardRatio)` — the two
  radial halves of a glyph box painted on an arc, and their difference. A
  `textPath` inks only one side of its baseline, and the flip decides which, so
  a flipped run's arc is drawn that difference further out and its glyphs land
  in the same band an unflipped run's do. One model, two callers: act labels
  (the radial-band invariant in `actLabels.ts`) and scene titles (the same
  invariant in `sceneTitles.ts`), differing only in which pair of token ratios
  they carry. `ResolvedLayout.actLabelBaselineShift` carries the act label's
  painter-side `dy`, which the same model accounts for; a scene title takes no
  such offset.
- **Text fitting**: `fitTextToWidth(text, availableWidth, fontSize)`, plus
  `estimateTextWidth`, `AVERAGE_GLYPH_WIDTH_RATIO` and `TRUNCATION_MARK` — the
  visible form of a string in the space it is painted in, an ellipsis marking
  the cut. Feed it `ScenePlacement.labelLength`.
  Width is estimated, not measured (these functions are pure and DOM-free); see
  `textFit.ts` for the calibration and which way its error is biased.
  `staticArcLabel(text, availableWidth, fontSize)` is the fit a scene arc
  actually paints: the same result, withheld entirely when the cut would leave
  fewer than `MINIMUM_TRUNCATED_LABEL_GLYPHS` glyphs — the `1…` confetti a dense
  book's inner rings otherwise fill with (DEVIATIONS.md 2026-08-14). A title
  that fits whole is never withheld, however short.
- **Title expansion**: `expandedTitleArc({ tree, placementId, title }) →
  ExpandedTitleArc | null` — the baseline arc one title takes when the reader
  points at it, anchored at the placement's own start, grown clockwise for as
  far as the full title needs, clamped at the act boundary **on that ring**, and
  fitted with an ellipsis only when even the act cannot carry it. It also
  returns `suppressedPlacementIds`: the neighbouring labels the run is written
  over, so the painter withholds ink rather than deciding anything. Arcs never
  move (the plugin repacks its act; this does not — DEVIATIONS.md 2026-08-14).
  Per PLACEMENT, not per scene: a multi-subplot scene expands on each of its
  rings independently.
- **Scene titles**: `sceneTitleBaselineInset(outwardInk, ringClearance)`,
  `sceneTitleBaselineRadius(innerRadius, outerRadius, inset)`,
  `sceneTitleArc(input) -> SceneTitleArc` and `SCENE_TITLE_ARC_INSET` — how far
  inside its ring the title baseline sits (from the title's own outward ink,
  never the raw font size), the clamp that keeps it out of the ring's inner
  half, the baseline arc itself, and the gap it leaves at each end of that arc.
  `sceneTitleArc` owns the upright flip and its radial compensation together, so
  a lower-half title reads the right way up AND inks the same band of its ring
  as an upper-half one.
- **Center hub**: nothing. The middle of the wheel paints no text in any state
  (DEVIATIONS.md 2026-08-11), so the layout math that fitted lines inside the
  circle is gone rather than kept warm. `LayoutConfig.hubRadius` remains — the
  empty disc is where the ring stack starts.
- **Polar math primitives**: `degToRad`, `radToDeg`, `polarToCartesian`,
  `annularSectorPath`, `fullAnnulusPath`, `directedArcPath`,
  `isUprightReversed`, `actGapHalfAngleDeg`, `fmt`, and the
  `Point` type — the building blocks `layout()` composes into act wedges and
  scene arc placements (constant-linear-width act gaps; see
  `DEVIATIONS.md` for the deliberate divergence from the plugin's angular
  gaps).

Stage 1 uses one chronological angular grid per act. Subplot membership selects
radial rings; a multi-subplot scene repeats in aligned rings without receiving
extra angular width. Act and scene label baselines are emitted in `LayoutTree`,
so the React painter performs no polar geometry.

The wheel's rim (`LayoutConfig.wheelRadius`) is fixed and the subplot rings
share the band inside it, so ring thickness is derived from the ring count: a
12-subplot manuscript paints thin rings inside the same circle a 3-subplot one
fills with thick ones, and both render their text at the same apparent size.

`LayoutDocument`/`LayoutScene` are the minimal structural shape this package
needs — it does not import `timeline-schema`'s `TimelineDocument`, but a
`TimelineDocument` is structurally assignable to `LayoutDocument`. Deep
imports past `.` are blocked by the package's `exports` map.

## Dependency graph

```
timeline-layout ──▶ timeline-schema
```

(Structurally only — see above; there is no `import` from `timeline-schema`
in this package's source today. It never depends on `timeline-tokens` or
`timeline-react`.) `timeline-react` is the only consumer: it calls `layout()`
and pairs the result with token dimensions to paint SVG.
