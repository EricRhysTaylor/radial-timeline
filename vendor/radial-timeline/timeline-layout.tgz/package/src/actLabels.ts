/**
 * Where an act's label sits on the rim.
 *
 * An act label is anchored to that act's **start boundary** and lies
 * clockwise of it — *inside the act it names* — on a fixed-length arc outside
 * the rim. Act 1 starts at 0deg, so its label begins at 12 o'clock and reads
 * clockwise into act 1; every later act's label begins on its own proportional
 * boundary (120deg apart for three acts, 90deg for four) and reads into its own
 * wedge.
 *
 * **This is a deliberate deviation from the plugin** (Eric's direction,
 * 2026-08-11). The plugin's goldens (v6.2.6) put the label on the *other* side
 * of the same boundary: `fixtures/pride-and-prejudice/golden.svg` and the other
 * two fixtures carry radius 790, three 60deg arcs — 298.85->358.85,
 * 58.85->118.85, 178.85->238.85 — each *ending* 1.15deg short of its own act's
 * start boundary (0/120/240), text right-aligned to that end
 * (`startOffset="100%"`, `text-anchor="end"`), so every label is painted over
 * the *previous* act's wedge. The engine mirrors that about the boundary: same
 * boundary, same gutter shortfall, same 60deg baseline, opposite side — a label
 * now names the wedge it is drawn on. The shortfall itself is still taken from
 * the engine's own act gutter rather than the plugin's magic constant, and the
 * reading direction is still righted (see `THE BOUNDARY-ANCHORING INVARIANT`
 * below).
 *
 * ## THE BOUNDARY-ANCHORING INVARIANT
 *
 * For every act, in every act count, flipped or not, the painted glyphs of
 * `Act N` occupy the angular stretch
 *
 *   [actStartAngle + gapHalfAngle, actStartAngle + gapHalfAngle + textExtent]
 *
 * — immediately clockwise of that act's own start boundary, inside that act's
 * own sector, never reaching past `actStartAngle + 60deg`.
 *
 * Two things have to agree for that to hold, and this module is the one place
 * that decides both: which direction the baseline is drawn (which end of the
 * emitted path carries the boundary), and which end of the path the text is
 * anchored to. They are computed from a single `reversed` here — deriving them
 * separately is exactly how act 2 of a three-act wheel ended up painted upside
 * down against its boundary (Eric, repeatedly; fixed 2026-08-10).
 *
 * The flip decision is made on **the stretch the glyphs occupy**, not on the
 * 60deg baseline they hang off. Those still differ, and the case simply moved
 * acts: under the old convention it was act 2 of three (glyphs past 90deg on a
 * baseline whose midpoint was 88.85deg), which painted "Act 2" upside down
 * against its boundary until the test was fixed. Here it is act 3 of three —
 * glyphs at 241.0..246.1deg, squarely on the lower half, hanging off a baseline
 * whose own midpoint is 271.0deg, nominally the upper half. Ask the baseline
 * and act 3 renders upside down.
 *
 * ## THE RADIAL-BAND INVARIANT
 *
 * The flip changes the reading direction and the radial side the glyphs stand
 * on — and nothing else may follow from it. A `textPath` inks one side of its
 * baseline only: outward when the path runs clockwise, inward when it runs
 * counterclockwise. One shared baseline radius therefore paints two different
 * bands, which is what Eric saw on the Pride & Prejudice render (2026-08-11):
 * unflipped "Act 1" standing further off the rim than flipped "Act 2" and
 * "Act 3". So a flipped label's arc is drawn `flipRadiusOffset` further out —
 * the difference between the label's outward and inward ink
 * (`arcTextFlipRadiusOffset` in `arcTextInk.ts`) — and every act's glyphs
 * land in the same radial band, the one the canvas is sized for.
 */

import { directedArcPath, isUprightReversed, radToDeg } from './polar';
import { estimateTextWidth } from './textFit';

/**
 * Angular length of an act-label arc, degrees.
 *
 * Constant in the plugin regardless of act count (60deg for both its 3-act
 * and 4-act goldens), so it is a constant here too — clamped to the act's own
 * span for act counts dense enough that 60deg would reach past the act's END
 * boundary and collide with the next act's label.
 */
export const ACT_LABEL_ARC_DEGREES = 60;

export interface ActLabelArcInput {
  center: Readonly<{ x: number; y: number }>;
  /**
   * Nominal radius of the label baseline — the radius an UNFLIPPED label is
   * drawn at. A flipped one is drawn `flipRadiusOffset` further out so both
   * ink the same band.
   */
  radius: number;
  /** Nominal (un-gapped) start boundary of the act, degrees. */
  actStartAngle: number;
  /** Nominal angular span of one act, degrees. */
  actSpan: number;
  /**
   * Half-width of the act gutter at `radius`, degrees. The label starts this
   * far past the boundary, so it never straddles the gap the wedges leave
   * open.
   */
  gapHalfAngle: number;
  /** The label's text, e.g. `"Act 2"`. Only its length is used. */
  label: string;
  /**
   * Size the label is painted at, in the wheel's units. `0` means "no labels
   * configured" (a caller doing pure geometry): the glyphs then have no extent
   * and the flip is decided at the boundary itself.
   */
  labelFontSize: number;
  /**
   * How far outward to move the baseline arc when the label is flipped, in the
   * wheel's units — `arcTextFlipRadiusOffset` (`arcTextInk.ts`), which is the
   * label's outward ink less its inward ink.
   *
   * Defaults to `0`: a caller with no ink model configured gets the raw
   * baseline radius for every label, which is the right answer for pure
   * geometry and the wrong one for anything painted (see the radial-band
   * invariant above).
   */
  flipRadiusOffset?: number;
}

export interface ActLabelArc {
  /**
   * SVG path `d` for the label baseline — at `radius`, or at
   * `radius + flipRadiusOffset` when the label is flipped.
   */
  path: string;
  /** Angular start of the arc — the act's start boundary, plus the gutter. */
  startAngle: number;
  /** Angular end of the arc in wheel coordinates (not path direction). */
  endAngle: number;
  /**
   * Estimated angular width of the painted glyphs at `radius`, degrees.
   *
   * The text runs forward from `startAngle` by this much (the invariant at the
   * top of this file). Estimated with the same glyph-width ratio the fit math
   * uses (`estimateTextWidth`), because layout is pure and has no DOM to
   * measure in.
   */
  textExtentDegrees: number;
  /**
   * Which end of `path` the label text hugs.
   *
   * `false` when the path runs clockwise: the act boundary is the path's
   * start, so the text is left-aligned there (`startOffset="0"`,
   * `text-anchor="start"`). `true` when the glyphs land on the lower half of
   * the wheel and the baseline is therefore drawn counterclockwise to keep
   * them upright: the boundary is then the path's *end*, so the text is
   * right-aligned there (`startOffset="100%"`, `text-anchor="end"`). Either way
   * the label occupies the same stretch of rim, touching the boundary from
   * inside its own act — only the reading direction differs.
   */
  anchorAtPathEnd: boolean;
}

/**
 * Angular width of a label's glyphs at a given radius, degrees.
 *
 * The one place act-label extent is computed: `actLabelArc` uses it to decide
 * the flip, and the invariant tests use it to say where the glyphs must land.
 *
 * @throws if `radius` is not positive (via `actLabelArc`'s own guard, or
 *   directly — a zero radius has no angular measure at all).
 */
export function actLabelTextExtentDegrees(
  label: string,
  labelFontSize: number,
  radius: number,
): number {
  if (radius <= 0) {
    throw new Error(`Act label text extent needs a positive radius; received ${radius}.`);
  }
  if (labelFontSize <= 0) return 0;
  return radToDeg(estimateTextWidth(label, labelFontSize) / radius);
}

/**
 * The label baseline arc for one act.
 *
 * @throws if the act span or the label radius is not positive — a
 *   zero-or-negative span cannot carry a baseline, and the caller has a
 *   config bug worth naming.
 */
export function actLabelArc(input: ActLabelArcInput): ActLabelArc {
  const { center, radius, actStartAngle, actSpan, gapHalfAngle, label, labelFontSize } = input;
  const flipRadiusOffset = input.flipRadiusOffset ?? 0;
  if (radius <= 0) {
    throw new Error(`Act label arc needs a positive radius; received ${radius}.`);
  }
  if (actSpan <= 0) {
    throw new Error(`Act label arc needs a positive act span; received ${actSpan}.`);
  }

  const span = Math.min(ACT_LABEL_ARC_DEGREES, actSpan);
  const startAngle = actStartAngle + gapHalfAngle;
  const endAngle = startAngle + span;

  // The glyphs never fill the baseline — they hug its boundary end — so the
  // flip is decided on their own stretch, clamped to the baseline for a label
  // too long to fit it. It is measured on the NOMINAL radius: the compensated
  // one is not known until the flip is, and the two differ by well under a
  // percent (7 units in 790 at the engine's tokens), which moves the glyph
  // midpoint by ~0.02deg. A label that close to a half-boundary reads the same
  // either way.
  const reversed = isUprightReversed(
    startAngle,
    startAngle + Math.min(actLabelTextExtentDegrees(label, labelFontSize, radius), span),
  );

  // The radial-band invariant: a flipped label inks the inward side of its
  // baseline, so its baseline moves outward by the difference between the two
  // sides and the painted band comes out where an unflipped label's does.
  const arcRadius = reversed ? radius + flipRadiusOffset : radius;
  if (arcRadius <= 0) {
    throw new Error(
      `Act label flip compensation put the arc at radius ${arcRadius} ` +
        `(baseline ${radius}, offset ${flipRadiusOffset}); the offset is the label's outward ` +
        'ink less its inward ink and cannot exceed the baseline radius.',
    );
  }

  // Published at the radius actually drawn, so the stretch the invariant tests
  // re-derive is the stretch the painter fills.
  const textExtentDegrees = Math.min(
    actLabelTextExtentDegrees(label, labelFontSize, arcRadius),
    span,
  );

  return {
    // Drawn away from the boundary when not reversed, back toward it when it
    // is: one `reversed`, so the path direction and the anchor below cannot
    // disagree. Either way the path's boundary end is the one the text hugs.
    path: reversed
      ? directedArcPath(center.x, center.y, arcRadius, endAngle, startAngle)
      : directedArcPath(center.x, center.y, arcRadius, startAngle, endAngle),
    startAngle,
    endAngle,
    textExtentDegrees,
    anchorAtPathEnd: reversed,
  };
}
