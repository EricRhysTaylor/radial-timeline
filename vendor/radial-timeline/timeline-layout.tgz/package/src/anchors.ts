/**
 * Callout anchors — where a scene's synopsis panel should point.
 *
 * Stage 2 shows the hover/selection synopsis in an HTML panel beside the SVG
 * rather than as reflowed SVG text, so the painter needs a point (and a side
 * of the wheel) to hang that panel off. That is geometry, so it is computed
 * here as a pure function and carried on the LayoutTree — the React layer
 * assembles coordinates, it never derives them.
 */

import { polarToCartesian } from './polar';

/**
 * Which quarter of the wheel an anchor falls in, in the engine's angle
 * convention (0deg at the top, increasing clockwise):
 *
 *   [0, 90)    top-right
 *   [90, 180)  bottom-right
 *   [180, 270) bottom-left
 *   [270, 360) top-left
 */
export type AnchorQuadrant = 'top-right' | 'bottom-right' | 'bottom-left' | 'top-left';

export interface SceneAnchor {
  /** Anchor point in layout (SVG viewBox) units. */
  x: number;
  y: number;
  /** Arc midpoint angle, degrees, normalized to [0, 360). */
  angle: number;
  /** Radius the anchor sits at — the radial midline of the scene's band. */
  radius: number;
  quadrant: AnchorQuadrant;
  /** Anchor position as a 0..1 fraction of the canvas, for CSS placement. */
  fractionX: number;
  fractionY: number;
}

export interface ArcAnchorInput {
  center: Readonly<{ x: number; y: number }>;
  size: Readonly<{ width: number; height: number }>;
  innerRadius: number;
  outerRadius: number;
  startAngle: number;
  endAngle: number;
}

/** Normalize an angle to the half-open range [0, 360). */
function normalizedAngle(angle: number): number {
  return ((angle % 360) + 360) % 360;
}

/** Which half of the frame a full-height panel occupies. */
export type FrameHalf = 'left' | 'right';

/**
 * The half of the frame a scene's meta panel takes: the one its arc is NOT in.
 *
 * The panel is full height and half width, so the only choice it has is a
 * side, and the only rule it needs is "not on top of the thing being read".
 * A quadrant on the right of the wheel sends the panel left, and vice versa;
 * the vertical half is irrelevant to a panel that is already full height.
 * Geometry, so it lives here — the React layer picks a class name with it, it
 * does not work it out (ENGINEERING.md §4).
 */
export function oppositeHalf(quadrant: AnchorQuadrant): FrameHalf {
  return quadrant === 'top-right' || quadrant === 'bottom-right' ? 'left' : 'right';
}

export function anchorQuadrant(angleDeg: number): AnchorQuadrant {
  const angle = normalizedAngle(angleDeg);
  if (angle < 90) return 'top-right';
  if (angle < 180) return 'bottom-right';
  if (angle < 270) return 'bottom-left';
  return 'top-left';
}

/**
 * The anchor for an annular-sector scene arc: the midpoint of its angular
 * span at the radial midline of its ring band.
 *
 * @throws if the canvas has no area — a zero width/height would make the
 *   fractional coordinates `Infinity`/`NaN` and silently place every panel in
 *   the same corner (fail clearly instead).
 */
export function arcAnchor(input: ArcAnchorInput): SceneAnchor {
  const { center, size, innerRadius, outerRadius, startAngle, endAngle } = input;
  if (size.width <= 0 || size.height <= 0) {
    throw new Error(
      `Cannot anchor a callout on a canvas of ${size.width}x${size.height}: ` +
        'width and height must both be positive.',
    );
  }

  const angle = normalizedAngle((startAngle + endAngle) / 2);
  const radius = (innerRadius + outerRadius) / 2;
  const point = polarToCartesian(center.x, center.y, radius, angle);

  return {
    x: point.x,
    y: point.y,
    angle,
    radius,
    quadrant: anchorQuadrant(angle),
    fractionX: point.x / size.width,
    fractionY: point.y / size.height,
  };
}
