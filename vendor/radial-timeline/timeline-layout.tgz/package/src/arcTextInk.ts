/**
 * Where text painted on an arc puts its ink relative to that arc.
 *
 * Text on an arc does not straddle its baseline the way text in a box does: a
 * `textPath` places each glyph with its baseline on the path and its "up"
 * direction on ONE side of it — the side decided by the direction the path is
 * drawn. Drawn clockwise, the glyphs stand with their caps pointing outward;
 * drawn counterclockwise (the flip that keeps lower-half text the right way
 * up), they stand with their caps pointing inward. The band of ink is the same
 * thickness either way and lands on opposite sides of the same radius.
 *
 * So a run of arc text has an ink box with two radial halves, and both are
 * needed:
 *
 *   - `arcTextOutwardInk` — the half that reaches outward. For an act label
 *     this is what the canvas has to reserve (`frame.ts`); for a scene title it
 *     is what its baseline is inset from the ring's outer edge by
 *     (`sceneTitles.ts`).
 *   - `arcTextInwardInk` — the half that reaches the other way.
 *   - `arcTextFlipRadiusOffset` — their difference, which is how far a flipped
 *     run's baseline has to move outward to paint into the same band an
 *     unflipped one paints into.
 *
 * That last one is the fix for what Eric saw on the Pride & Prejudice render:
 * first on the act labels (2026-08-11) — "Act 1" (unflipped, ink outward)
 * standing further off the rim than "Act 2" and "Act 3" (flipped, ink inward),
 * all three hanging off one shared baseline radius — and then, the same day and
 * for the same reason, on the scene titles of the wheel's lower half, riding
 * ~18 units low inside their rings. One radius, two bands; one module, one
 * correction. See DEVIATIONS.md.
 *
 * The ratios themselves are the token layer's (`typography`), derived there
 * from one set of face metrics; this module only turns them into units and
 * never invents a metric of its own. Which pair a caller passes is what makes
 * the answer an act label's or a scene title's — the geometry is identical,
 * which is why there is one module and not two.
 */

/** Shared guard: every ink quantity is a font size times a non-negative ratio. */
function ink(fontSize: number, ratio: number, name: string): number {
  if (fontSize < 0 || ratio < 0) {
    throw new Error(
      `Arc text ${name} cannot be negative; received fontSize=${fontSize}, ratio=${ratio}.`,
    );
  }
  return fontSize * ratio;
}

/**
 * How far outward a run of arc text reaches past its baseline arc.
 *
 * The one place this product is computed. `frameRadius` adds an act label's to
 * the label radius to size the canvas and `sceneTitleBaselineInset` sets a
 * title's baseline in from the ring edge by a title's — and the tests assert
 * both against this same function, so a reserve and the thing it reserves for
 * cannot drift apart.
 *
 * @throws if either input is negative.
 */
export function arcTextOutwardInk(fontSize: number, outwardInkRatio: number): number {
  return ink(fontSize, outwardInkRatio, 'outward ink');
}

/**
 * How far inward a run of arc text reaches past its baseline arc — the other
 * half of the same glyph box.
 *
 * @throws if either input is negative.
 */
export function arcTextInwardInk(fontSize: number, inwardInkRatio: number): number {
  return ink(fontSize, inwardInkRatio, 'inward ink');
}

/**
 * How far outward a FLIPPED run of arc text must have its baseline arc drawn so
 * its glyphs occupy the same radial band an unflipped run's glyphs occupy.
 *
 * Derivation, with `R` the nominal baseline radius, `out` the outward ink and
 * `in` the inward ink:
 *
 * ```
 *   unflipped band = [R − in,  R + out]
 *   flipped   band = [R − out, R + in ]      (the mirror: ink on the other side)
 *   flipped at R+Δ = [R + Δ − out, R + Δ + in]
 *   equal bands   ⇒ Δ = out − in
 * ```
 *
 * Both edges give the same Δ because the two bands are the same thickness, so
 * the compensation is a pure translation — no clamping, no second constant. At
 * the engine's tokens it is `28 × (0.75 − 0.5)` = 7 units for an act label on a
 * 790-unit baseline, and `24 × (1.0 − 0.25)` = 18 units for a scene title.
 *
 * @throws if any input is negative (via the ink functions).
 */
export function arcTextFlipRadiusOffset(
  fontSize: number,
  outwardInkRatio: number,
  inwardInkRatio: number,
): number {
  return (
    arcTextOutwardInk(fontSize, outwardInkRatio) - arcTextInwardInk(fontSize, inwardInkRatio)
  );
}
