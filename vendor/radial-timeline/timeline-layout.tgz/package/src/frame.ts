/**
 * The canvas the wheel is drawn on.
 *
 * The frame is derived from what the wheel actually paints, never configured:
 * the rim, plus the act-label band that sits outside it, plus the act-label
 * ink that reaches outward past its baseline arc. Anything more is dead margin
 * — the wheel would shrink inside its own viewBox for no reason — and anything
 * less clips the act labels.
 *
 * Measured against the plugin's exported goldens (v6.2.6, all three Stage 0
 * fixtures): rim 766, act-label baseline 790, viewBox half-size 800 — i.e. the
 * plugin reserves exactly *half* the act-label font size (`766 + 24 + 20/2`)
 * for the glyphs. That reserve is too small for its own labels: half the font
 * size is where the *em box* centre sits, not where the ink stops. The painter
 * drops the label's baseline half an x-height off its arc, so ink reaches
 * `ascent - xHeight / 2` outward, which for a UI sans stack is ~0.44em of cap
 * and more once a capital carries an accent. At 20px that is up to ~0.75em =
 * 15 units against a 10-unit reserve, and Eric saw the result: "Act 1" at 12
 * o'clock painting into the top row of the frame (engine dark baseline,
 * 2026-08-10).
 *
 * So the engine keeps the plugin's rim and offset and widens only the ink
 * reserve, to `actLabelFontSize * actLabelOutwardInkRatio` (0.75 — the bound,
 * see the token). Half-size becomes 805 rather than 800: the wheel gives up
 * 0.6% of its frame and stops being clipped. The inward half of the glyph box
 * is not part of this — it reaches over the rim, where there is a whole wheel
 * of room — but it is not ignored either: it is what decides how far a flipped
 * label's arc moves outward so every label inks the same band
 * (`arcTextInk.ts`). Because the two halves swap sides under the flip, that
 * compensation leaves the outermost ink at exactly the radius reserved here,
 * for every act, flipped or not.
 */

import { arcTextOutwardInk } from './arcTextInk';

export interface FrameRadiusInput {
  /** Outer radius of the ring stack — the wheel's rim. */
  wheelRadius: number;
  /** Radial distance from the rim out to the act-label baseline. */
  actLabelOffset: number;
  /**
   * Act-label font size. Act labels are centred on their baseline arc, so part
   * of one rises past it — how much is `actLabelOutwardInkRatio`.
   */
  actLabelFontSize: number;
  /**
   * Fraction of `actLabelFontSize` the label's ink reaches outward past its
   * baseline arc (`typography.actLabelOutwardInkRatio`).
   */
  actLabelOutwardInkRatio: number;
}

/**
 * Radius of the square canvas: half its width, and the distance from the
 * center to any edge.
 *
 * @throws if any input is negative, or the wheel has no radius at all — a
 *   zero-radius frame would divide by zero downstream in the anchor
 *   fractions rather than reporting the bad config here.
 */
export function frameRadius(input: FrameRadiusInput): number {
  const { wheelRadius, actLabelOffset, actLabelFontSize, actLabelOutwardInkRatio } = input;
  if (wheelRadius <= 0) {
    throw new Error(`Frame needs a positive wheelRadius; received ${wheelRadius}.`);
  }
  if (actLabelOffset < 0 || actLabelFontSize < 0 || actLabelOutwardInkRatio < 0) {
    throw new Error(
      `Frame margins cannot be negative; received actLabelOffset=${actLabelOffset}, ` +
        `actLabelFontSize=${actLabelFontSize}, ` +
        `actLabelOutwardInkRatio=${actLabelOutwardInkRatio}.`,
    );
  }
  return (
    wheelRadius + actLabelOffset + arcTextOutwardInk(actLabelFontSize, actLabelOutwardInkRatio)
  );
}
