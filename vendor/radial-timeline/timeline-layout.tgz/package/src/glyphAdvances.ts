/**
 * How wide each glyph is, as a fraction of the font size.
 *
 * ## Why a table and not an average
 *
 * This package is pure and runs without a DOM, so a string's width has to be
 * predicted rather than measured. That prediction used to be one number —
 * every character charged `0.5em`, an average of mixed-case English prose —
 * and one number cannot be right for two strings: `1 Train Station` renders at
 * `0.40em` a character and `9 Homecoming` at `0.55em`. The average was rounded
 * **up** so the wide case would not have its tail amputated inside the clip,
 * which meant the narrow case was over-charged by a quarter and stopped a
 * quarter short of its cell (Eric, 2026-08-21: "why all the ellipses when
 * there is still plenty of room?").
 *
 * Summing per-character advances removes the trade entirely: both strings are
 * predicted within a few percent, so a title fills the room it actually has.
 * The plugin reached the same conclusion from the other direction — its
 * `FontMetricsCache` measures each glyph in the DOM and sums them. This is
 * that table, committed as data so the engine stays pure.
 *
 * ## What was measured, and the direction of the error
 *
 * Each ratio is the **maximum** advance across the three faces the engine's
 * sans stack actually resolves to in the field — SF Pro (Apple platforms, via
 * `system-ui`), Arial (metric-compatible with the Liberation Sans that Linux
 * and CI resolve), and Roboto (Android) — measured through a canvas at
 * 1000px and rounded to three decimals.
 *
 * Taking the maximum keeps the bias pointing the safe way. An over-estimate
 * costs a character that an ellipsis was going to hide anyway; an
 * under-estimate lets a `textPath` drop the tail, ellipsis and all, which is
 * the defect the whole fitting layer exists to prevent. Summing per-character
 * maxima also ignores kerning, which in these faces is overwhelmingly
 * negative: measured across representative titles the sum runs 2–4% wider
 * than any of the three faces really paints. That margin is the headroom the
 * old flat 15% used to buy, and it is now structural rather than a guess.
 *
 * Faces outside that set (notably Segoe UI, which Windows resolves
 * `system-ui` to) are not calibrated here. They are narrower than Arial
 * throughout, so the maxima still bound them — but see
 * `EXPANDED_TITLE_WIDTH_HEADROOM` in `titleExpansion.ts` for the small margin
 * that covers the ones nobody measured.
 */

/**
 * Advance ratios, grouped by width so the table reads as a table.
 *
 * Grouped rather than one entry per character because the interesting fact
 * about `ABEKPSVXY` is that they are all the same width — a per-character
 * listing hides that, and hides a typo in it too.
 */
const GLYPH_ADVANCE_GROUPS: ReadonlyArray<readonly [number, string]> = [
  [0.222, '‘’'],
  [0.239, 'j'],
  [0.243, 'il'],
  [0.254, "'"],
  [0.26, '|¦'],
  [0.278, ' !,.:;I ÌÍÎÏìíîï'],
  [0.322, '[]'],
  [0.327, 't'],
  [0.333, '¡·'],
  [0.338, 'r{}'],
  [0.342, '('],
  [0.347, 'f'],
  [0.348, ')'],
  [0.364, '“”'],
  [0.367, '²³¹'],
  [0.4, '°'],
  [0.403, '"'],
  [0.41, '\\'],
  [0.412, '/'],
  [0.429, '-•'],
  [0.431, '*'],
  [0.447, 'ª'],
  [0.455, 'º'],
  [0.5, '`vxyz¨´¸ýÿ'],
  [0.507, 'k'],
  [0.516, 's'],
  [0.523, 'cç'],
  [0.552, 'J¯'],
  [0.556, '?L_aehnuàáâãäåèéêëñùúûü'],
  [0.561, 'bgp'],
  [0.562, '17'],
  [0.564, 'd'],
  [0.566, '2¶'],
  [0.568, 'q'],
  [0.57, 'oòóôõö'],
  [0.576, 'µþ'],
  [0.585, '5'],
  [0.586, 'ð'],
  [0.592, '3'],
  [0.6, '8'],
  [0.604, '$+4<=>^¢£¥¬±×÷'],
  [0.606, '0'],
  [0.611, 'FT¿ßø'],
  [0.613, '§'],
  [0.616, '#'],
  [0.617, '69Z'],
  [0.619, '«»'],
  [0.656, '–'],
  [0.667, 'ABEKPSVXYÀÁÂÃÄÅÈÉÊËÝÞ'],
  [0.669, '&'],
  [0.68, '~'],
  [0.713, '¤'],
  [0.722, 'CDHNRUÇÐÑÙÚÛÜ'],
  [0.751, 'w'],
  [0.778, 'GOQÒÓÔÕÖØ'],
  [0.786, '®'],
  [0.834, '¼½¾'],
  [0.847, '©'],
  [0.873, 'M'],
  [0.876, 'm'],
  [0.889, '%æ'],
  [0.944, 'W'],
  [1, 'Æ—…'],
  [1.015, '@'],
  // The soft hyphen is an invisible line-break opportunity, not ink. It is
  // listed so it costs nothing rather than falling to the unknown-glyph
  // ratio, which would reserve a whole em for a character that paints none.
  [0, '­'],
];

/**
 * Advance ratio for a character the table does not list.
 *
 * A full em, because what actually turns up outside Latin-1 is CJK and
 * emoji — both full-width — and because the safe direction for an unknown is
 * to reserve too much rather than let it overrun the clip. A Latin title
 * never reaches this branch.
 */
export const UNKNOWN_GLYPH_ADVANCE_RATIO = 1;

const RATIO_BY_CHARACTER: ReadonlyMap<string, number> = new Map(
  GLYPH_ADVANCE_GROUPS.flatMap(([ratio, characters]) =>
    [...characters].map((character) => [character, ratio] as const),
  ),
);

/**
 * Advance of one character as a fraction of the font size.
 *
 * Takes a single character (one code point); anything the table does not
 * carry gets `UNKNOWN_GLYPH_ADVANCE_RATIO`.
 */
export function glyphAdvanceRatio(character: string): number {
  return RATIO_BY_CHARACTER.get(character) ?? UNKNOWN_GLYPH_ADVANCE_RATIO;
}

/**
 * Summed advance of every character in `text`, as a fraction of the font
 * size. Iterates by code point, so an astral character counts once.
 */
export function textAdvanceRatio(text: string): number {
  let total = 0;
  for (const character of text) total += glyphAdvanceRatio(character);
  return total;
}
