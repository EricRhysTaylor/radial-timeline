import { arcTextFlipRadiusOffset, arcTextOutwardInk } from './arcTextInk';
import { actLabelArc } from './actLabels';
import { arcAnchor } from './anchors';
import { frameRadius } from './frame';
import { orderedScenes } from './narrative';
import {
  SCENE_TITLE_ARC_INSET,
  sceneTitleArc,
  sceneTitleBaselineInset,
  sceneTitleBaselineRadius,
} from './sceneTitles';
import { DEFAULT_SUBPLOT, subplotRings, subplotsOf } from './subplots';
import {
  actGapHalfAngleDeg,
  annularSectorPath,
  degToRad,
  fullAnnulusPath,
} from './polar';
import type {
  ActWedge,
  LayoutConfig,
  LayoutDocument,
  LayoutScene,
  LayoutTree,
  ResolvedLayout,
  ScenePlacement,
  VoidCell,
} from './types';

const FULL_CIRCLE = 360;

/** Pick the correct path builder: a full ring when the span is ~360deg, else a sector.
 * Exported for `titleExpansion.ts`, which grows a placement's own cell with it —
 * the expanded cell must be built by the same arithmetic as the cell it grows. */
export function sectorPath(
  cx: number,
  cy: number,
  innerRadius: number,
  outerRadius: number,
  startAngle: number,
  endAngle: number,
): string {
  const span = endAngle - startAngle;
  return span >= FULL_CIRCLE - 1e-6
    ? fullAnnulusPath(cx, cy, innerRadius, outerRadius)
    : annularSectorPath(cx, cy, innerRadius, outerRadius, startAngle, endAngle);
}

/**
 * Compute a deterministic radial layout.
 *
 * Core radial model:
 *   - The wheel's rim is fixed (`wheelRadius`) and the subplot rings share
 *     the band between `hubRadius` and it, so ring thickness falls out of the
 *     ring count instead of being configured. The canvas is then derived
 *     tightly from the rim (`frame.ts`): the wheel fills its viewBox at the
 *     same proportion for every manuscript, and font sizes mean the same
 *     thing from book to book.
 *   - The wheel is divided into `actCount` EQUAL angular wedges. The gap
 *     between acts is a constant LINEAR width (`actGapWidth`, clamped by
 *     `maxActGapAngle`) rather than a constant angle — see
 *     `actGapHalfAngleDeg` in `polar.ts`. Each ring gets its own gap angle,
 *     evaluated at that ring's inner radius (the smallest, most conservative
 *     radius in its band), so bands near the hub shrink their angular span
 *     more than outer bands.
 *   - Subplots become concentric rings: the main throughline outermost, then
 *     the rest busiest-first (`subplots.ts`), matching the plugin's stack.
 *   - Within an act, every item receives one equal angular SLOT in manuscript
 *     order, and every ring shares that one slot sequence. A scene's subplot
 *     memberships choose radial rings, not separate angular subdivisions, so
 *     multi-subplot scenes repeat in aligned rings and slot 0 is the act's
 *     first scene on every ring. See `TimelineArrangement`.
 *   - Every slot a ring's subplot does NOT occupy becomes a void cell
 *     (`LayoutTree.voids`). The empty cells are output, not absence: without
 *     them a ring whose first scene sits in slot 5 reads as if it started the
 *     act, which is exactly the misreading Eric reported (2026-08-10).
 *   - Act and scene label baselines are geometry output, not painter math.
 *     Act labels terminate at their act's START boundary (`actLabels.ts`);
 *     scene titles start at the start of their arc, so the fitting done by
 *     `fitTextToWidth` costs a title its tail, never its opening words. Both
 *     flip on the wheel's lower half to stay upright, and a flipped run of
 *     either is drawn slightly further out — one ink model, one correction
 *     (`arcTextInk.ts`) — so that its glyphs land in the same radial band as an
 *     unflipped one's: act labels in the band the canvas is sized for, scene
 *     titles in the band their ring's inset defines.
 *
 * Pure and deterministic: same input always yields the same tree.
 *
 * @throws if `arrangement` is anything but `'narrative'` — `'chronologue'` is
 *   reserved and unimplemented, and answering a chronological request with a
 *   manuscript-order wheel would be a confident wrong answer.
 * @throws if `hubRadius` is not inside `wheelRadius` — there would be no band
 *   for the rings to divide.
 * @throws if a scene references an act outside 1..actCount (fail clearly).
 * @throws if the clamped act gap consumes an act's entire angular span at
 *   some ring's radius (fail clearly rather than render a collapsed/negative
 *   span).
 */
export function layout(document: LayoutDocument, config: LayoutConfig): LayoutTree {
  const { arrangement, actCount, actGapWidth, maxActGapAngle, wheelRadius, hubRadius } = config;

  if (arrangement !== 'narrative') {
    throw new Error(
      `Unsupported arrangement "${arrangement}". This engine implements 'narrative' ` +
        "(manuscript order) only; 'chronologue' is reserved and not built yet.",
    );
  }

  const actLabelOffset = config.actLabelOffset ?? 0;
  const actLabelFontSize = config.actLabelFontSize ?? 0;
  const actLabelOutwardInkRatio = config.actLabelOutwardInkRatio ?? 0;
  const actLabelInwardInkRatio = config.actLabelInwardInkRatio ?? 0;
  const actLabelBaselineShiftRatio = config.actLabelBaselineShiftRatio ?? 0;
  const sceneLabelFontSize = config.sceneLabelFontSize ?? 0;
  const sceneLabelOutwardInkRatio = config.sceneLabelOutwardInkRatio ?? 0;
  const sceneLabelInwardInkRatio = config.sceneLabelInwardInkRatio ?? 0;
  const scenes = orderedScenes(document);

  // The two ink ratios are one glyph box seen from both sides (`arcTextInk`),
  // and the flip compensation is their difference. Half a model would silently
  // shove every flipped label outward by a whole outward-ink, so it is a
  // config bug worth naming rather than a default worth guessing.
  if (actLabelOutwardInkRatio > 0 !== actLabelInwardInkRatio > 0) {
    throw new Error(
      'Act-label ink is one box, not two knobs: configure actLabelOutwardInkRatio and ' +
        `actLabelInwardInkRatio together, or neither. Received outward=${actLabelOutwardInkRatio}, ` +
        `inward=${actLabelInwardInkRatio}.`,
    );
  }

  // Same box, same rule, for the titles: their two ratios are the two sides of
  // one glyph box and their difference is the flip compensation. A title size
  // with no model at all is refused as well, because unlike an act label a
  // title's baseline is PLACED from its outward ink — guessing it would put
  // every title in the wheel at the wrong radius, not just the flipped ones.
  if (sceneLabelOutwardInkRatio > 0 !== sceneLabelInwardInkRatio > 0) {
    throw new Error(
      'Scene-title ink is one box, not two knobs: configure sceneLabelOutwardInkRatio and ' +
        `sceneLabelInwardInkRatio together, or neither. Received ` +
        `outward=${sceneLabelOutwardInkRatio}, inward=${sceneLabelInwardInkRatio}.`,
    );
  }
  if (sceneLabelFontSize > 0 && sceneLabelOutwardInkRatio <= 0) {
    throw new Error(
      `A painted scene title has a glyph box: sceneLabelFontSize=${sceneLabelFontSize} needs ` +
        'sceneLabelOutwardInkRatio and sceneLabelInwardInkRatio too (typography.scene* in ' +
        'timeline-tokens). Omit the font size for geometry with no titles.',
    );
  }

  if (hubRadius < 0 || wheelRadius <= hubRadius) {
    throw new Error(
      `The ring stack needs a band to divide: hubRadius=${hubRadius} must be >= 0 and ` +
        `strictly less than wheelRadius=${wheelRadius}.`,
    );
  }

  // --- Rings: the plugin's subplot stack, innermost first (`subplots.ts`). ---
  const ringIndex = new Map<string, number>(
    subplotRings(document).map((ring) => [ring.subplot, ring.index]),
  );
  const ringCount = Math.max(ringIndex.size, 1);

  // The rim is fixed; the rings share the space up to it. A 12-subplot book
  // therefore paints 12 thin rings inside the same circle a 3-subplot book
  // fills with 3 thick ones, instead of growing a bigger wheel (and a bigger
  // viewBox) that would render its text at a different apparent size.
  const ringWidth = (wheelRadius - hubRadius) / ringCount;
  const ringInner = (r: number): number => hubRadius + r * ringWidth;
  const ringOuter = (r: number): number => hubRadius + (r + 1) * ringWidth;
  const ringStackOuter = wheelRadius;

  // The title baseline is placed from the title's own ink, not from a second
  // configured number that could drift out of step with it. A caller doing
  // geometry without labels configures no size and gets no inset.
  const sceneLabelInset =
    sceneLabelFontSize > 0
      ? sceneTitleBaselineInset(
          arcTextOutwardInk(sceneLabelFontSize, sceneLabelOutwardInkRatio),
          config.sceneLabelRingClearance ?? 0,
        )
      : 0;
  // How far a flipped title's baseline moves outward so its glyphs land in the
  // same band of its ring an unflipped title's do (`arcTextInk.ts`).
  const sceneTitleFlipRadiusOffset = arcTextFlipRadiusOffset(
    sceneLabelFontSize,
    sceneLabelOutwardInkRatio,
    sceneLabelInwardInkRatio,
  );

  const labelRadius = ringStackOuter + actLabelOffset;
  const canvasRadius = frameRadius({
    wheelRadius,
    actLabelOffset,
    actLabelFontSize,
    actLabelOutwardInkRatio,
  });
  const center = { x: canvasRadius, y: canvasRadius };

  const resolved: ResolvedLayout = {
    center,
    size: { width: canvasRadius * 2, height: canvasRadius * 2 },
    ringCount,
    ringWidth,
    ringStackOuterRadius: ringStackOuter,
    sceneLabelFontSize,
    sceneLabelInset,
    sceneLabelFlipRadiusOffset: sceneTitleFlipRadiusOffset,
    actLabelBaselineShift: actLabelFontSize * actLabelBaselineShiftRatio,
    rings: [...ringIndex.entries()].map(([subplot, index]) => ({
      subplot,
      index,
      innerRadius: ringInner(index),
      outerRadius: ringOuter(index),
      dPath: fullAnnulusPath(center.x, center.y, ringInner(index), ringOuter(index)),
    })),
  };

  // --- Angular ranges per act (equal division, per-ring linear-width gap). ---
  const actSpan = FULL_CIRCLE / actCount;

  // How far a flipped label's baseline moves outward so its glyphs land in the
  // same radial band an unflipped label's do (`arcTextInk.ts`).
  const labelFlipRadiusOffset = arcTextFlipRadiusOffset(
    actLabelFontSize,
    actLabelOutwardInkRatio,
    actLabelInwardInkRatio,
  );

  /**
   * Gapped [start, end] angle for `act` on the ring whose inner radius is
   * `ringInnerR`. Shared by act-wedge band construction and scene placement
   * so both agree exactly on where a given ring's slice of an act sits.
   */
  const actRangeForRing = (act: number, ringInnerR: number): { start: number; end: number } => {
    const base = (act - 1) * actSpan;
    const halfGap = actGapHalfAngleDeg(ringInnerR, actGapWidth, maxActGapAngle);
    const start = base + halfGap;
    const end = base + actSpan - halfGap;
    if (end <= start) {
      throw new Error(
        `Act ${act}: the act gap (actGapWidth=${actGapWidth}, clamped to ` +
          `maxActGapAngle=${maxActGapAngle}deg full-gap) consumes the entire ` +
          `${actSpan}deg act span at radius ${ringInnerR}. Reduce actGapWidth / ` +
          `maxActGapAngle, or increase hubRadius / ringWidth.`,
      );
    }
    return { start, end };
  };

  // --- Group scenes by act, validating act range. ---
  const byAct = new Map<number, LayoutScene[]>();
  for (const scene of scenes) {
    if (scene.act < 1 || scene.act > actCount) {
      throw new Error(
        `Scene "${scene.id}" references act ${scene.act}, outside 1..${actCount}.`,
      );
    }
    const bucket = byAct.get(scene.act) ?? [];
    bucket.push(scene);
    byAct.set(scene.act, bucket);
  }

  const acts: ActWedge[] = [];
  const placements: ScenePlacement[] = [];
  const voids: VoidCell[] = [];
  const ringSubplots = [...ringIndex.entries()]
    .sort((a, b) => a[1] - b[1])
    .map(([subplot]) => subplot);
  // A document with no scenes still draws one ring; name it the throughline
  // rather than leaving its void cells without a subplot.
  const subplotForRing = (ring: number): string => ringSubplots[ring] ?? DEFAULT_SUBPLOT;

  for (let act = 1; act <= actCount; act += 1) {
    const actScenes = byAct.get(act) ?? [];

    // Build the act wedge as one gapped band per ring — the gap narrows near
    // the hub (constant linear gutter width) instead of one uniform angle
    // flaring outward across the whole radial stack. Every ring gets a band
    // (even ones with no scenes in this act) so the act background stays
    // continuous across the full ring stack, matching the prior single-sector
    // behavior.
    const bandPaths: string[] = [];
    for (let ringIdx = 0; ringIdx < ringCount; ringIdx += 1) {
      const inner = ringInner(ringIdx);
      const outer = ringOuter(ringIdx);
      const bandRange = actRangeForRing(act, inner);
      bandPaths.push(sectorPath(center.x, center.y, inner, outer, bandRange.start, bandRange.end));
    }

    // The label hangs off this act's START boundary, clockwise of it, inside
    // the act it names — act 1's begins at 12 o'clock. It starts past the
    // boundary by the same half-gutter the wedges leave open at the label
    // radius, so it never straddles the gap. The text is passed in because its
    // own angular extent is what decides the upright flip (`actLabels.ts`).
    const label = `Act ${act}`;
    const labelArc = actLabelArc({
      center,
      radius: labelRadius,
      actStartAngle: (act - 1) * actSpan,
      actSpan,
      gapHalfAngle: actGapHalfAngleDeg(labelRadius, actGapWidth, maxActGapAngle),
      label,
      labelFontSize: actLabelFontSize,
      flipRadiusOffset: labelFlipRadiusOffset,
    });

    acts.push({
      act,
      startAngle: (act - 1) * actSpan,
      endAngle: act * actSpan,
      innerRadius: hubRadius,
      outerRadius: ringStackOuter,
      sceneIds: actScenes.map((s) => s.id),
      dPath: bandPaths.join(' '),
      labelPath: labelArc.path,
      labelAnchorAtPathEnd: labelArc.anchorAtPathEnd,
      labelTextExtentDegrees: labelArc.textExtentDegrees,
      label,
    });

    // One manuscript-order slot grid per act, shared by every ring. Subplots
    // select only the ring. This is the essential geometry contract visible in
    // the plugin goldens: a scene does not widen merely because its subplot has
    // fewer entries.
    /** Slot geometry for `slot` on the ring whose inner radius is `inner`. */
    const slotRange = (
      act_: number,
      inner: number,
      slot: number,
    ): { start: number; end: number } => {
      const range = actRangeForRing(act_, inner);
      const segment = (range.end - range.start) / actScenes.length;
      return { start: range.start + slot * segment, end: range.start + (slot + 1) * segment };
    };

    /** Which rings each slot fills — the complement is this act's voids. */
    const occupiedRingsBySlot = actScenes.map(
      (scene) => new Set(subplotsOf(scene).map((subplot) => ringIndex.get(subplot) ?? 0)),
    );

    actScenes.forEach((scene, slot) => {
      for (const subplot of subplotsOf(scene)) {
        const ring = ringIndex.get(subplot) ?? 0;
        const inner = ringInner(ring);
        const outer = ringOuter(ring);
        const { start, end } = slotRange(act, inner, slot);
        // The title baseline hugs the ring's outer edge (the plugin's look),
        // but never crosses the band's midline however thin the ring gets.
        // That clamp fixes the GLYPH BAND; the arc a flipped title is actually
        // drawn on then moves off it, so the band stays put either way — which
        // is why the clamp comes first and the compensation second.
        const titleArc = sceneTitleArc({
          center,
          radius: sceneTitleBaselineRadius(inner, outer, sceneLabelInset),
          startAngle: start,
          endAngle: end,
          flipRadiusOffset: sceneTitleFlipRadiusOffset,
        });
        // Measured at the radius the path was drawn at, so the length quoted to
        // the fitter is the length of the path the glyphs are placed on.
        const titleArcLength = degToRad(end - start) * titleArc.radius;
        placements.push({
          placementId: `${scene.id}:${ring}`,
          sceneId: scene.id,
          subplot,
          act,
          ring,
          slot,
          startAngle: start,
          endAngle: end,
          innerRadius: inner,
          outerRadius: outer,
          dPath: sectorPath(center.x, center.y, inner, outer, start, end),
          labelPath: titleArc.path,
          labelStartOffset: SCENE_TITLE_ARC_INSET,
          labelLength: Math.max(0, titleArcLength - 2 * SCENE_TITLE_ARC_INSET),
          anchor: arcAnchor({
            center,
            size: resolved.size,
            innerRadius: inner,
            outerRadius: outer,
            startAngle: start,
            endAngle: end,
          }),
        });
      }
    });

    // The empty cells, ordered ring-then-slot. An act with no scenes has no
    // slots to divide, so each of its rings gets one full-act void instead.
    for (let ring = 0; ring < ringCount; ring += 1) {
      const inner = ringInner(ring);
      const outer = ringOuter(ring);
      const subplot = subplotForRing(ring);
      const pushVoid = (slot: number, start: number, end: number): void => {
        voids.push({
          voidId: `void:${act}:${ring}:${slot}`,
          act,
          ring,
          subplot,
          slot,
          startAngle: start,
          endAngle: end,
          innerRadius: inner,
          outerRadius: outer,
          dPath: sectorPath(center.x, center.y, inner, outer, start, end),
        });
      };

      if (actScenes.length === 0) {
        const range = actRangeForRing(act, inner);
        pushVoid(-1, range.start, range.end);
        continue;
      }
      for (let slot = 0; slot < actScenes.length; slot += 1) {
        if (occupiedRingsBySlot[slot]?.has(ring)) continue;
        const { start, end } = slotRange(act, inner, slot);
        pushVoid(slot, start, end);
      }
    }
  }

  // Stable output ordering: acts already ordered; scenes by manuscript order.
  const sceneOrder = new Map(scenes.map((scene, index) => [scene.id, index]));
  placements.sort((a, b) => {
    const orderDifference = (sceneOrder.get(a.sceneId) ?? 0) - (sceneOrder.get(b.sceneId) ?? 0);
    return orderDifference !== 0 ? orderDifference : a.ring - b.ring;
  });

  return { resolved, acts, scenes: placements, voids };
}
