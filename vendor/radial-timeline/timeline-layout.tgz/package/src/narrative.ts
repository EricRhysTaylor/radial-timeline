/**
 * Manuscript reading order — the one ordering the whole engine agrees on.
 *
 * The wheel is painted in this order, keyboard navigation steps through it,
 * and subplot rings count their scenes from it. Keeping it in one
 * pure function means the painter can never disagree with the geometry about
 * which scene comes next.
 */

import type { LayoutDocument, LayoutScene } from './types';

/** Only scene items enter the geometry; an absent `itemType` means scene. */
function isSceneItem(scene: LayoutScene): boolean {
  return scene.itemType === undefined || scene.itemType === 'scene';
}

/** Deterministic comparison: `order` ascending, ties broken by `id`. */
function byOrderThenId(a: LayoutScene, b: LayoutScene): number {
  if (a.order !== b.order) return a.order - b.order;
  return a.id < b.id ? -1 : a.id > b.id ? 1 : 0;
}

/**
 * Scene items in manuscript order. Non-scene matter (plot, beat, backdrop) is
 * excluded; ties on `order` break by `id` so the result is stable for any
 * input permutation.
 *
 * Returns a fresh array — the caller's document is never mutated.
 */
export function orderedScenes(document: LayoutDocument): LayoutScene[] {
  return document.scenes.filter(isSceneItem).sort(byOrderThenId);
}
