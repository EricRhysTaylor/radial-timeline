/**
 * Polar geometry primitives — textbook math, written fresh.
 *
 * Angle convention: degrees, 0deg at the top (12 o'clock), increasing
 * CLOCKWISE. This matches how a manuscript wheel reads and maps cleanly onto
 * SVG's y-down coordinate space:
 *   x = cx + r * sin(theta)
 *   y = cy - r * cos(theta)
 */

export interface Point {
  x: number;
  y: number;
}

export function degToRad(deg: number): number {
  return (deg * Math.PI) / 180;
}

export function radToDeg(rad: number): number {
  return (rad * 180) / Math.PI;
}

/** Point on a circle of `radius` centered at (cx, cy), at `angleDeg` (0=top, CW). */
export function polarToCartesian(
  cx: number,
  cy: number,
  radius: number,
  angleDeg: number,
): Point {
  const rad = degToRad(angleDeg);
  return {
    x: cx + radius * Math.sin(rad),
    y: cy - radius * Math.cos(rad),
  };
}

/** Round to `dp` decimals and strip trailing zeros, for compact, stable path strings. */
export function fmt(n: number, dp = 3): string {
  const rounded = Number(n.toFixed(dp));
  // Normalize -0 to 0.
  return Object.is(rounded, -0) ? '0' : String(rounded);
}

function point(cx: number, cy: number, r: number, a: number): string {
  const p = polarToCartesian(cx, cy, r, a);
  return `${fmt(p.x)} ${fmt(p.y)}`;
}

/** Normalize an angle to the half-open range [0, 360). */
function normalizedAngle(angle: number): number {
  return ((angle % 360) + 360) % 360;
}

/**
 * Whether text laid on the arc spanning `[startAngle, endAngle]` must be drawn
 * counterclockwise so its glyphs read left-to-right instead of upside down.
 *
 * The rule is a single fact about the wheel — an arc whose midpoint falls on
 * the lower half (90deg..270deg exclusive) carries upside-down text when drawn
 * clockwise — and it must be asked about **the stretch the glyphs actually
 * occupy**, not about whatever baseline they are anchored to. The two are the
 * same thing for a scene title, which fills its arc from one end; they are not
 * for an act label, which hugs one end of a 60deg baseline and can therefore
 * sit entirely on the lower half of an arc whose own midpoint is on the upper
 * half (see `actLabels.ts`, and DEVIATIONS.md 2026-08-10 §4). Exported so the
 * rule lives in exactly one place and both callers ask it the same question.
 *
 * Both callers also compensate the flip radially — the flipped run inks the
 * other side of its baseline (`arcTextInk.ts`) — which is why neither of them
 * can be handed a finished path by this module: the answer to this question is
 * an input to the radius the path is drawn at.
 */
export function isUprightReversed(startAngle: number, endAngle: number): boolean {
  const midpoint = normalizedAngle((startAngle + endAngle) / 2);
  return midpoint > 90 && midpoint < 270;
}

/**
 * Open circular arc from `fromAngle` to `toAngle` **in path order** — the
 * direction is the caller's, not this function's.
 *
 * `fromAngle > toAngle` emits a counterclockwise arc (sweep 0), which is what
 * reverses a `textPath`'s reading direction. Text callers ask
 * `isUprightReversed` first and come here with the answer, so the emitted path,
 * their own anchoring and the radius they compensate the flip by can never be
 * derived from two different answers.
 *
 * @throws if the swept angle is zero, or greater than one revolution.
 */
export function directedArcPath(
  cx: number,
  cy: number,
  radius: number,
  fromAngle: number,
  toAngle: number,
): string {
  const span = Math.abs(toAngle - fromAngle);
  if (span === 0 || span > 360) {
    throw new Error(`Text arc span must be > 0 and <= 360 degrees; received ${fmt(span)}.`);
  }
  const sweep = toAngle > fromAngle ? 1 : 0;
  const largeArc = span > 180 ? 1 : 0;

  return [
    `M ${point(cx, cy, radius, fromAngle)}`,
    `A ${fmt(radius)} ${fmt(radius)} 0 ${largeArc} ${sweep} ${point(cx, cy, radius, toAngle)}`,
  ].join(' ');
}

/**
 * SVG path `d` for an annular sector (ring segment) spanning `[startAngle,
 * endAngle]` between `innerRadius` and `outerRadius`. Angles increase
 * clockwise; the span must be < 360 (use `fullAnnulusPath` for a complete ring).
 */
export function annularSectorPath(
  cx: number,
  cy: number,
  innerRadius: number,
  outerRadius: number,
  startAngle: number,
  endAngle: number,
): string {
  const span = endAngle - startAngle;
  const largeArc = Math.abs(span) > 180 ? 1 : 0;

  const outerStart = point(cx, cy, outerRadius, startAngle);
  const outerEnd = point(cx, cy, outerRadius, endAngle);
  const innerEnd = point(cx, cy, innerRadius, endAngle);
  const innerStart = point(cx, cy, innerRadius, startAngle);

  // Outer arc runs start->end clockwise (sweep 1); inner arc returns end->start (sweep 0).
  const parts = [
    `M ${outerStart}`,
    `A ${fmt(outerRadius)} ${fmt(outerRadius)} 0 ${largeArc} 1 ${outerEnd}`,
    `L ${innerEnd}`,
    `A ${fmt(innerRadius)} ${fmt(innerRadius)} 0 ${largeArc} 0 ${innerStart}`,
    'Z',
  ];
  return parts.join(' ');
}

/**
 * Angular half-gap (degrees) to apply on each side of an act boundary angle
 * at a given `radius`, so the visible gutter between act wedges has constant
 * LINEAR width (`actGapWidth`, same unit space as radii) instead of
 * flaring outward at larger radii.
 *
 * Derivation: arc length = radius * angle(radians), so the full gap angle
 * that produces `actGapWidth` of arc length at `radius` is
 * `actGapWidth / radius` radians. That is converted to degrees (this
 * codebase's angular unit) and clamped at `maxActGapAngle` — also a FULL gap
 * angle, in degrees — for small radii where the angle would otherwise blow
 * up, then halved to get the half-gap applied on each side of the boundary.
 *
 * `actGapWidth <= 0` disables the gap unconditionally and short-circuits
 * before dividing, so `radius === 0` is safe in that case. For
 * `actGapWidth > 0` and `radius === 0`, the width-driven angle is `Infinity`,
 * which clamps to `maxActGapAngle` — still a well-defined (non-NaN) result;
 * callers are responsible for detecting when that clamped gap consumes an
 * act's entire angular span and failing loudly instead of rendering garbage.
 */
export function actGapHalfAngleDeg(
  radius: number,
  actGapWidth: number,
  maxActGapAngle: number,
): number {
  if (actGapWidth <= 0) return 0;
  const fullAngleFromWidth = radToDeg(actGapWidth / radius);
  return Math.min(fullAngleFromWidth, maxActGapAngle) / 2;
}

/**
 * SVG path `d` for a complete annulus (full ring, 360deg). Drawn as two
 * half-arcs per edge because a single 360deg arc is degenerate in SVG.
 */
export function fullAnnulusPath(
  cx: number,
  cy: number,
  innerRadius: number,
  outerRadius: number,
): string {
  const oTop = point(cx, cy, outerRadius, 0);
  const oBottom = point(cx, cy, outerRadius, 180);
  const iTop = point(cx, cy, innerRadius, 0);
  const iBottom = point(cx, cy, innerRadius, 180);

  return [
    `M ${oTop}`,
    `A ${fmt(outerRadius)} ${fmt(outerRadius)} 0 1 1 ${oBottom}`,
    `A ${fmt(outerRadius)} ${fmt(outerRadius)} 0 1 1 ${oTop}`,
    `M ${iTop}`,
    `A ${fmt(innerRadius)} ${fmt(innerRadius)} 0 1 0 ${iBottom}`,
    `A ${fmt(innerRadius)} ${fmt(innerRadius)} 0 1 0 ${iTop}`,
    'Z',
  ].join(' ');
}
