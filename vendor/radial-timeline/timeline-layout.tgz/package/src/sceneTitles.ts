/**
 * Where a scene title sits on its arc.
 *
 * Placement only — the string that actually gets painted is decided by
 * `fitTextToWidth` in `textFit.ts`.
 *
 * ## THE RADIAL-BAND INVARIANT
 *
 * A title on the lower half of the wheel has its baseline drawn
 * counterclockwise so its glyphs read the right way up. That flip changes the
 * reading direction and the radial side the glyphs stand on — and nothing else
 * may follow from it. A `textPath` inks one side of its baseline only: outward
 * when the path runs clockwise, inward when it runs counterclockwise. One
 * shared baseline radius therefore paints two different bands, `out − in`
 * apart, which at the engine's 24-unit titles is 18 units — measured at 18.6 on
 * the Pride & Prejudice render, where every lower-half title sat that much
 * deeper inside its ring than every upper-half one (DEVIATIONS.md 2026-08-11).
 *
 * So a flipped title's arc is drawn `flipRadiusOffset` further out — the
 * difference between the title's outward and inward ink
 * (`arcTextFlipRadiusOffset` in `arcTextInk.ts`) — and every title's glyphs land
 * in the same radial band of their ring, whichever half of the wheel they are
 * on. It is the same correction, from the same ink model, that `actLabels.ts`
 * applies to act labels; the two differ only in which pair of ratios they carry
 * (a title stands on its baseline, an act label is centred on its arc by a
 * `dy`, so their outward halves are not the same fraction of an em).
 *
 * The compensation is applied to the ALREADY-CLAMPED baseline radius, never
 * before it: `sceneTitleBaselineRadius` decides where the band goes, and the
 * offset then moves a flipped arc so that its band is that same one. Clamping
 * the compensated radius instead would pull flipped titles back down by
 * whatever the clamp bit off, which is the asymmetry this exists to remove.
 */

import { directedArcPath, isUprightReversed } from './polar';

/**
 * Gap between the start of a scene's arc and its first glyph, in layout
 * units — the plugin's `startOffset="4"`, kept because a title butted against
 * the divider between two arcs reads as belonging to neither. An equal gap is
 * reserved at the far end, so a fitted title never touches the next scene's
 * edge either.
 */
export const SCENE_TITLE_ARC_INSET = 4;

/**
 * How far inside a ring's outer edge a scene title's baseline sits.
 *
 * Derived, never configured alongside the font size. A title is drawn on an
 * `alphabetic` baseline with no `dy`, so its glyphs rise *outward* from that arc
 * by exactly its outward ink (`arcTextOutwardInk`, the face's ascent at that
 * size); the inset is therefore that ink plus whatever daylight is wanted at the
 * ring's edge. The plugin's goldens fix that daylight at 4 units (a flat 22-unit
 * inset under an 18-unit font, on all three fixtures and every ring thickness),
 * and this function is why raising the title size — or revising the face
 * metrics — cannot leave a stale inset behind and paint glyphs into the
 * neighbouring ring.
 *
 * Takes the ink, not the font size: the one place a title's outward reach is
 * computed is the ink model, and passing the size here would be a second,
 * silent claim that a glyph rises exactly one em.
 *
 * @throws if the outward ink is not positive or the clearance is negative —
 *   either is a config bug worth naming rather than a silently misplaced
 *   baseline.
 */
export function sceneTitleBaselineInset(outwardInk: number, ringClearance: number): number {
  if (outwardInk <= 0) {
    throw new Error(
      `Scene-title baseline needs positive outward ink; received ${outwardInk}. ` +
        'It is the title font size times its outward ink ratio (`arcTextInk.ts`).',
    );
  }
  if (ringClearance < 0) {
    throw new Error(
      `Scene-title ring clearance cannot be negative; received ${ringClearance}.`,
    );
  }
  return outwardInk + ringClearance;
}

/**
 * The nominal radius a title's baseline sits at inside its ring: the inset
 * measured in from the ring's outer edge, but never inside the ring's radial
 * midline however thin the ring gets.
 *
 * "Nominal" because it is where an UNFLIPPED title is drawn, and — the point of
 * the clamp — where the glyph band goes for a flipped one too: `sceneTitleArc`
 * moves the flipped ARC off this radius so the BAND stays on it.
 *
 * @throws if the ring is not a positive band.
 */
export function sceneTitleBaselineRadius(
  innerRadius: number,
  outerRadius: number,
  baselineInset: number,
): number {
  if (outerRadius <= 0 || outerRadius <= innerRadius) {
    throw new Error(
      `Scene-title baseline needs a ring with a positive band; received inner=${innerRadius}, ` +
        `outer=${outerRadius}.`,
    );
  }
  return Math.max(outerRadius - baselineInset, (innerRadius + outerRadius) / 2);
}

export interface SceneTitleArcInput {
  center: Readonly<{ x: number; y: number }>;
  /**
   * Nominal baseline radius — `sceneTitleBaselineRadius`. A flipped title is
   * drawn `flipRadiusOffset` further out so both ink the same band.
   */
  radius: number;
  /** Angular start of the scene's arc, degrees (0 = 12 o'clock, clockwise). */
  startAngle: number;
  /** Angular end of the scene's arc, degrees. */
  endAngle: number;
  /**
   * How far outward to move the baseline arc when the title is flipped, in the
   * wheel's units — `arcTextFlipRadiusOffset` (`arcTextInk.ts`), the title's
   * outward ink less its inward ink.
   *
   * Defaults to `0`: a caller with no ink model configured gets the raw
   * baseline radius for every title, which is the right answer for pure
   * geometry and the wrong one for anything painted (see the radial-band
   * invariant above).
   */
  flipRadiusOffset?: number;
}

export interface SceneTitleArc {
  /**
   * SVG path `d` for the title baseline — at `radius`, or at
   * `radius + flipRadiusOffset` when the title is flipped.
   *
   * The title fills this path from its start (`SCENE_TITLE_ARC_INSET` along it),
   * so the path's own direction is the reading direction and the painter needs
   * no anchor decision of its own.
   */
  path: string;
  /** Whether the baseline runs counterclockwise to keep the glyphs upright. */
  flipped: boolean;
  /** The radius `path` was actually drawn at — compensated when `flipped`. */
  radius: number;
}

/**
 * The baseline arc for one scene title.
 *
 * Unlike an act label, a title fills its arc from one end, so the flip is
 * decided on the arc itself (`isUprightReversed`) — the stretch of glyphs and
 * the baseline are the same stretch.
 *
 * @throws if the span is not positive or exceeds one revolution, or if the flip
 *   compensation would put the arc at a non-positive radius.
 */
export function sceneTitleArc(input: SceneTitleArcInput): SceneTitleArc {
  const { center, radius, startAngle, endAngle } = input;
  const flipRadiusOffset = input.flipRadiusOffset ?? 0;
  const span = endAngle - startAngle;
  if (span <= 0 || span > 360) {
    throw new Error(`Scene-title arc span must be > 0 and <= 360 degrees; received ${span}.`);
  }
  if (radius <= 0) {
    throw new Error(`Scene-title arc needs a positive radius; received ${radius}.`);
  }

  // SVG cannot express a complete circle with one arc. A lone scene owning the
  // whole wheel needs only a stable baseline, so leave an imperceptible seam.
  const safeEnd = span === 360 ? endAngle - 0.001 : endAngle;
  const flipped = isUprightReversed(startAngle, safeEnd);

  // The radial-band invariant: a flipped title inks the inward side of its
  // baseline, so its baseline moves outward by the difference between the two
  // sides and the painted band comes out where an unflipped title's does.
  const arcRadius = flipped ? radius + flipRadiusOffset : radius;
  if (arcRadius <= 0) {
    throw new Error(
      `Scene-title flip compensation put the arc at radius ${arcRadius} ` +
        `(baseline ${radius}, offset ${flipRadiusOffset}); the offset is the title's outward ` +
        'ink less its inward ink and cannot exceed the baseline radius.',
    );
  }

  return {
    path: flipped
      ? directedArcPath(center.x, center.y, arcRadius, safeEnd, startAngle)
      : directedArcPath(center.x, center.y, arcRadius, startAngle, safeEnd),
    flipped,
    radius: arcRadius,
  };
}
