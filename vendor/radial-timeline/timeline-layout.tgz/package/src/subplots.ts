/**
 * Subplot → ring assignment.
 *
 * A subplot becomes a concentric ring. `layout()` builds its ring stack from
 * this, and consumers that need the same ordering without running a full
 * layout (a legend, a filter panel) call `subplotRings` directly — one
 * derivation, one answer.
 *
 * **The ring order is the plugin's**, because a wheel whose subplots sit at
 * different radii than the author's own wheel is a different picture of the
 * same book. See {@link subplotRings} for the rule and the one deliberate
 * difference inside it.
 */

import { orderedScenes } from './narrative';
import type { LayoutDocument, LayoutScene } from './types';

/** The throughline every scene falls back to when it declares no subplot. */
export const DEFAULT_SUBPLOT = 'Main Plot';

/** A subplot's declared names, defaulted to the main throughline. */
export function subplotsOf(scene: LayoutScene): readonly string[] {
  return scene.subplots && scene.subplots.length > 0 ? scene.subplots : [DEFAULT_SUBPLOT];
}

export interface SubplotRing {
  subplot: string;
  /** Ring index, 0 = innermost. */
  index: number;
  /** Scenes on this ring — a scene counts once per subplot it declares. */
  sceneCount: number;
}

/**
 * Every subplot in the document, in ring order (index 0 = innermost).
 *
 * The rule, matching the plugin's `masterSubplotOrder`
 * (`renderer/utils/Precompute.ts`) and its outermost-first ring mapping
 * (`renderer/renderers/RingRenderer.ts`):
 *
 *   1. The main throughline (`DEFAULT_SUBPLOT`) takes the **outermost** ring
 *      whenever the book has one — it is the spine, and it reads first.
 *   2. Every other subplot follows by **scene count, descending**: the busiest
 *      subplot sits nearest the rim, where its ring is longest and its titles
 *      have the most arc to stand on.
 *   3. Ties break by subplot name, ascending.
 *
 * This function reports that stack **inside out**, because `index` addresses a
 * radius and radii grow outward: the last entry of the plugin's master order is
 * `index: 0`, and the throughline is `index: ringCount - 1`.
 *
 * A scene counts once per subplot it declares, and non-scene matter (plot,
 * beat, backdrop) contributes neither rings nor counts — it never enters the
 * geometry (`orderedScenes`), so it must not be allowed to move a ring either.
 *
 * **One deliberate difference:** the name tiebreak compares code points, where
 * the plugin uses `localeCompare`. `timeline-layout` is pure and deterministic
 * by charter (ENGINEERING.md §4), and `localeCompare` answers differently under
 * different ICU data — the same book would stack its rings differently on two
 * machines. The two agree for ASCII subplot names and can disagree only between
 * two subplots that already have identical scene counts.
 */
export function subplotRings(document: LayoutDocument): SubplotRing[] {
  const sceneCounts = new Map<string, number>();
  for (const scene of orderedScenes(document)) {
    for (const subplot of subplotsOf(scene)) {
      sceneCounts.set(subplot, (sceneCounts.get(subplot) ?? 0) + 1);
    }
  }

  const outermostFirst = [...sceneCounts.entries()].sort(([nameA, countA], [nameB, countB]) => {
    if (nameA === DEFAULT_SUBPLOT) return -1;
    if (nameB === DEFAULT_SUBPLOT) return 1;
    if (countA !== countB) return countB - countA;
    return nameA < nameB ? -1 : nameA > nameB ? 1 : 0;
  });

  return outermostFirst
    .reverse()
    .map(([subplot, sceneCount], index) => ({ subplot, index, sceneCount }));
}
