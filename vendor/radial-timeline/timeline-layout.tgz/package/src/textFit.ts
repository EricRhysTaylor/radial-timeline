/**
 * Fitting a string to the space it is painted in.
 *
 * Text that is too long for its box is not a rendering problem to be absorbed
 * downstream: SVG silently drops the glyphs that fall past the end of a
 * `textPath`, so an over-long string arrives on screen as a word fragment with
 * no signal that anything was cut. The fix is to decide the visible string
 * here, deterministically, so the DOM text and the painted text are the same
 * string and the cut is marked.
 *
 * One shape of that problem is left in the engine: `fitTextToWidth` — one line,
 * cut with an ellipsis — for a scene title on its arc. (A multi-line wrap lived
 * here too while the hub carried text; the hub is empty now, so the wrap went
 * with it rather than staying on as an untended export.) The full text always
 * remains reachable: the arc is a label, while the scene-meta panel and the
 * arc's `aria-label` carry the whole thing.
 *
 * `staticArcLabel` is the same fit with one further judgement on top — whether
 * the result is worth painting at all. See it for why a two-glyph floor exists.
 *
 * **Width is estimated, not measured.** These functions are pure and run
 * without a DOM, so there is no `getComputedTextLength` to call. A string's
 * width is the sum of its glyphs' advances (`glyphAdvances.ts`) — see that
 * module for the faces behind the table and the direction its error is
 * deliberately biased.
 */

import { glyphAdvanceRatio, textAdvanceRatio } from './glyphAdvances';

/** The single character that marks truncated text. */
export const TRUNCATION_MARK = '…';

/**
 * Approximate rendered width of `text` at `fontSize`, in layout units.
 *
 * @throws if `fontSize` is not positive — a zero or negative size would make
 *   every string appear to fit (or to be infinitely wide) instead of
 *   reporting the bad token.
 */
export function estimateTextWidth(text: string, fontSize: number): number {
  if (fontSize <= 0) {
    throw new Error(`Text width needs a positive fontSize; received ${fontSize}.`);
  }
  return textAdvanceRatio(text) * fontSize;
}

/**
 * The visible form of `text` on a single line offering `availableWidth` units.
 *
 * Returns the text unchanged when it fits, a truncated head plus
 * `TRUNCATION_MARK` when it does not, and the empty string when not even one
 * character and the mark fit (the caller paints no label at all rather than a
 * lone ellipsis). The result is never estimated to be wider than
 * `availableWidth`.
 *
 * @throws if `fontSize` is not positive (via `estimateTextWidth`).
 */
export function fitTextToWidth(text: string, availableWidth: number, fontSize: number): string {
  const trimmed = text.trim();
  if (trimmed === '') return '';
  if (availableWidth <= 0) {
    // Still validate the font size: a caller passing 0 has a config bug
    // whether or not this particular line happens to be too short.
    estimateTextWidth(trimmed, fontSize);
    return '';
  }
  if (estimateTextWidth(trimmed, fontSize) <= availableWidth) return trimmed;

  const room = availableWidth - estimateTextWidth(TRUNCATION_MARK, fontSize);
  if (room <= 0) return '';

  // Walked one glyph at a time rather than divided out of an average: the
  // glyphs have different widths, so how many of them fit depends on which
  // ones they are. Iteration is by code point, so an astral character is
  // kept or dropped whole and the head can never end on half a pair.
  let head = '';
  let width = 0;
  for (const character of trimmed) {
    const next = width + glyphAdvanceRatio(character) * fontSize;
    if (next > room) break;
    width = next;
    head += character;
  }
  const trimmedHead = head.trimEnd();
  return trimmedHead === '' ? '' : trimmedHead + TRUNCATION_MARK;
}

/**
 * Fewest glyphs a *truncated* arc label must keep to earn its place on the
 * wheel.
 *
 * One glyph and an ellipsis is not a label — it is a mark that says a label was
 * attempted. On a dense book every short arc paints one of them and the wheel
 * fills with `1…` confetti that names nothing and hides the arc's own colour
 * under ink. Two is the floor because two glyphs can distinguish neighbours
 * (`12…` from `13…`) where one cannot.
 */
export const MINIMUM_TRUNCATED_LABEL_GLYPHS = 2;

/**
 * The string an arc paints as its STATIC label — the fit, plus the judgement
 * that a fragment this short is worse than nothing.
 *
 * Returns `''` when the arc is too short to carry a meaningful cut, and the
 * caller then paints no label at all. Nothing is lost by that silence: the
 * whole title is still in the arc's `aria-label` and in the scene-meta panel,
 * and pointing at the arc expands the title in full (`titleExpansion.ts`) —
 * which is what makes the floor an improvement rather than a subtraction.
 *
 * A title that fits ENTIRELY is always painted, however short: `7` is a
 * complete label, not a fragment, and a shared wheel's numbered scenes are
 * exactly that case.
 *
 * @throws if `fontSize` is not positive (via `fitTextToWidth`).
 */
export function staticArcLabel(text: string, availableWidth: number, fontSize: number): string {
  const fitted = fitTextToWidth(text, availableWidth, fontSize);
  if (fitted === '' || fitted === text.trim()) return fitted;
  if (!fitted.endsWith(TRUNCATION_MARK)) return fitted;
  const glyphsKept = [...fitted].length - [...TRUNCATION_MARK].length;
  return glyphsKept >= MINIMUM_TRUNCATED_LABEL_GLYPHS ? fitted : '';
}
