/**
 * What a scene title does when the reader points at it.
 *
 * A static title is cut to the arc it sits on (`textFit.ts`), and on a dense
 * book that arc is a sliver: the wheel fills with word-fragments that name
 * nothing. The answer is not a bigger arc — it is that the ONE title the reader
 * is asking about gets the room it needs, borrowed from the labels beside it,
 * for exactly as long as they are asking.
 *
 * ## The plugin's convention, which this reproduces
 *
 * Read off `SceneTitleExpansion.ts` / `SceneInteractionManager.ts` in the
 * Obsidian plugin (reference material — no code came across):
 *
 *   - **Anchored at the scene's own start.** The plugin's aligned-mode
 *     `expandIntoGap` keeps `hovered.startAngle` and grows `endAngle` alone;
 *     its repacking mode packs the act from its start boundary in manuscript
 *     order, so the expanded scene still begins where its own run of glyphs
 *     began. Either way a title loses its tail, never its opening words —
 *     which is the same promise the static fit makes.
 *   - **Growth runs clockwise, into the neighbours ahead.** Never
 *     counterclockwise into the scene behind.
 *   - **The act boundary is the wall.** `redistributeAngles` takes
 *     `actEndAngle` and bounds the expansion by the space available inside it;
 *     `expandIntoGap` stops at `segmentEndAngle`. Nothing crosses the act gap.
 *   - **Neighbours give way while it lasts.** The plugin shrinks the other
 *     scenes' arcs, which clips their titles to nothing as a side effect of the
 *     geometry.
 *
 * One thing is deliberately NOT reproduced (DEVIATIONS.md 2026-08-14,
 * amended 2026-08-18). The plugin *moves* its neighbours — every arc in the
 * act repacks — which makes the wheel jump under the cursor and cost the
 * plugin a whole anti-flicker apparatus (`suppressedGroups`, pointer-event
 * suppression, aligned-mode's separate code path). Here the neighbours never
 * move: the hovered placement's own CELL grows clockwise into FREE space only
 * — the void cells between it and the next occupied slot on its ring, walled
 * by the act boundary — and the title lives inside that grown cell, fitted
 * (ellipsis, never a silent clip) to whatever room it won. No other
 * placement's arc or label is ever touched or crossed (Eric, 2026-08-18:
 * "text must be inside the expanded cell"). The expansion is computed for a
 * placement, not for a scene: a multi-subplot scene appears on several rings,
 * and each copy expands into its own ring's free space or not at all.
 */

import { degToRad, radToDeg } from './polar';
import { sectorPath } from './layout';
import {
  SCENE_TITLE_ARC_INSET,
  sceneTitleArc,
  sceneTitleBaselineRadius,
} from './sceneTitles';
import { estimateTextWidth, fitTextToWidth } from './textFit';
import type { LayoutTree } from './types';

/**
 * Angular slack, in degrees, for comparisons between quantities that were
 * derived along different arithmetic paths (a slot boundary computed by
 * division vs. an extent computed from an arc length). Far below a paintable
 * angle at any radius this wheel uses, and far above float noise.
 */
const ANGLE_EPSILON = 1e-9;

/**
 * Headroom multiplier on the estimated text width for the expanded title.
 *
 * An expanded title is CLIPPED to its grown cell, so an under-estimate of its
 * width amputates the tail mid-word and eats the ellipsis with it (Eric,
 * 2026-08-18: "why is Home clipped?"). A static label can absorb that —
 * overflow drops off the open end of its path — but this one cannot, so the
 * cell is sized, and the text fitted, with a margin.
 *
 * It was 1.15 while `estimateTextWidth` was a flat average and could be a
 * quarter wrong in either direction. It now sums measured per-glyph advances
 * (`glyphAdvances.ts`) whose per-character maxima already run 2–4% wider than
 * any calibrated face really paints, so the margin left here covers only what
 * the table does not: a face outside the calibration set. Compounded on the
 * old average this constant was costing a narrow title — the common case —
 * about a third of its cell (Eric, 2026-08-21: "why all the ellipses when
 * there is still plenty of room?").
 */
const EXPANDED_TITLE_WIDTH_HEADROOM = 1.05;

export interface ExpandedTitleArcInput {
  /** The wheel the placement belongs to — supplies its geometry and title metrics. */
  tree: LayoutTree;
  /** Which placement's title is expanding (`ScenePlacement.placementId`). */
  placementId: string;
  /**
   * The title to fit, in full. Whatever the document says it is: on a shared
   * wheel `anonymizedView` has already reduced it to a scene number, and the
   * expansion has no opinion about that — a number is a short title.
   */
  title: string;
}

export interface ExpandedTitleArc {
  placementId: string;
  /** Baseline arc for the expanded title — same contract as `ScenePlacement.labelPath`. */
  labelPath: string;
  /** Distance along `labelPath` at which the title starts. */
  labelStartOffset: number;
  /** Arc length available to the title, measured at the radius the path was drawn at. */
  labelLength: number;
  /** The radius `labelPath` was drawn at — compensated when `flipped`. */
  radius: number;
  /** Whether the baseline runs counterclockwise to keep the glyphs upright. */
  flipped: boolean;
  /** Angular start — always the placement's own start. */
  startAngle: number;
  /** Angular end after expansion, never past the act boundary at this ring. */
  endAngle: number;
  /**
   * The string to paint: the whole title, or — when even the act's remaining
   * span cannot carry it — the longest head that fits, marked with an ellipsis.
   */
  text: string;
  /** True when `text` had to be cut. */
  truncated: boolean;
  /**
   * True when a boundary — the act's end, or the next occupied slot on this
   * ring — decided `endAngle` rather than the title's own length.
   */
  clamped: boolean;
  /**
   * The grown cell itself: the placement's sector redrawn from its own start
   * to the expanded `endAngle`, at its own ring radii. The painter fills it
   * with the scene's colour and clips the expanded title to it, so the text
   * can never leave the cell (Eric, 2026-08-18).
   */
  cellPath: string;
}

/**
 * Where this act's slot sequence ends on this ring — the act's gapped end
 * boundary at that radius.
 *
 * Taken from the tree rather than recomputed from config: every slot of an
 * act/ring is either a placement or a void cell (`VoidCell`), so the furthest
 * cell edge IS the boundary, and reading it here means the expansion cannot
 * disagree with the geometry it is expanding into.
 */
function actEndAngleForRing(tree: LayoutTree, act: number, ring: number): number {
  let end = Number.NEGATIVE_INFINITY;
  for (const placement of tree.scenes) {
    if (placement.act === act && placement.ring === ring) {
      end = Math.max(end, placement.endAngle);
    }
  }
  for (const cell of tree.voids) {
    if (cell.act === act && cell.ring === ring) {
      end = Math.max(end, cell.endAngle);
    }
  }
  return end;
}

/**
 * The grown cell one title expands into, and the baseline arc the title
 * paints along inside it.
 *
 * Anchored at the placement's own start and grown clockwise to whatever the
 * full title needs, bounded by the FREE space on its ring: the next occupied
 * slot is a wall, and so is the act boundary. When even that space cannot
 * carry the title, the cell takes the whole free span and `text` is the
 * fitted head — an ellipsis at maximum length, never a silent clip.
 *
 * Pure and deterministic, like everything in this package: the same tree, id
 * and title always give the same arc.
 *
 * @returns `null` when the title is blank — there is nothing to expand, and the
 *   painter has nothing to paint or suppress.
 * @throws if `placementId` names no placement in `tree` (a painter asking about
 *   an arc that is not on the wheel is a bug worth naming), or if the tree was
 *   laid out with no scene-title size at all (`sceneLabelFontSize`), in which
 *   case there are no titles to expand and the caller has confused two configs.
 */
export function expandedTitleArc(input: ExpandedTitleArcInput): ExpandedTitleArc | null {
  const { tree, placementId, title } = input;

  const placement = tree.scenes.find((candidate) => candidate.placementId === placementId);
  if (!placement) {
    throw new Error(
      `No placement "${placementId}" in this layout tree. Expansion is per PLACEMENT, not ` +
        'per scene: a multi-subplot scene has one id per ring (`ScenePlacement.placementId`).',
    );
  }

  const fontSize = tree.resolved.sceneLabelFontSize;
  if (fontSize <= 0) {
    throw new Error(
      'This wheel was laid out with no scene-title size (sceneLabelFontSize), so it paints no ' +
        'titles and has none to expand. Configure the title typography, or do not ask.',
    );
  }

  const trimmed = title.trim();
  if (trimmed === '') return null;

  // The band the glyphs land in is fixed by the ring, exactly as it is for the
  // static title — expansion is an ANGULAR change and nothing else, so a title
  // must not drift radially at the moment it is read.
  const nominalRadius = sceneTitleBaselineRadius(
    placement.innerRadius,
    placement.outerRadius,
    tree.resolved.sceneLabelInset,
  );

  // The same accounting `layout` does per slot — the leading inset, the
  // glyphs, and an equal trailing inset — with clip headroom on the glyphs
  // (see EXPANDED_TITLE_WIDTH_HEADROOM).
  const requiredArcLength =
    estimateTextWidth(trimmed, fontSize) * EXPANDED_TITLE_WIDTH_HEADROOM +
    2 * SCENE_TITLE_ARC_INSET;
  const requiredSpan = radToDeg(requiredArcLength / nominalRadius);

  const ownSpan = placement.endAngle - placement.startAngle;
  const actEnd = actEndAngleForRing(tree, placement.act, placement.ring);

  // The wall: the act's end, or the first occupied slot after this one on the
  // same ring — the cell grows through free (void) space only, and no other
  // placement's ink is ever crossed.
  let freeEnd = actEnd;
  for (const candidate of tree.scenes) {
    if (
      candidate.placementId !== placement.placementId &&
      candidate.act === placement.act &&
      candidate.ring === placement.ring &&
      candidate.startAngle > placement.startAngle + ANGLE_EPSILON
    ) {
      freeEnd = Math.min(freeEnd, candidate.startAngle);
    }
  }
  const availableSpan = freeEnd - placement.startAngle;

  // Never smaller than the arc the scene already owns (a short title keeps its
  // own slot), never larger than the free span left on this ring.
  const span = Math.max(ownSpan, Math.min(requiredSpan, availableSpan));
  const endAngle = placement.startAngle + span;
  const clamped = requiredSpan > availableSpan + ANGLE_EPSILON;

  const arc = sceneTitleArc({
    center: tree.resolved.center,
    radius: nominalRadius,
    startAngle: placement.startAngle,
    endAngle,
    flipRadiusOffset: tree.resolved.sceneLabelFlipRadiusOffset,
  });
  const labelLength = Math.max(0, degToRad(span) * arc.radius - 2 * SCENE_TITLE_ARC_INSET);

  // Only the clamped case can lose glyphs, and it is fitted against the
  // length actually available DIVIDED by the clip headroom — the same margin
  // the sizing above reserves, so the fitted head and its ellipsis render
  // inside the cell the clip enforces. The unclamped case is the full title
  // by construction — re-fitting it would let a float rounding on the
  // arithmetic path above cost a title its last character for no reason a
  // reader could ever see.
  const text = clamped
    ? fitTextToWidth(trimmed, labelLength / EXPANDED_TITLE_WIDTH_HEADROOM, fontSize)
    : trimmed;

  return {
    placementId: placement.placementId,
    labelPath: arc.path,
    labelStartOffset: SCENE_TITLE_ARC_INSET,
    labelLength,
    radius: arc.radius,
    flipped: arc.flipped,
    startAngle: placement.startAngle,
    endAngle,
    text,
    truncated: text !== trimmed,
    clamped,
    cellPath: sectorPath(
      tree.resolved.center.x,
      tree.resolved.center.y,
      placement.innerRadius,
      placement.outerRadius,
      placement.startAngle,
      endAngle,
    ),
  };
}
