/**
 * Structural inputs and outputs for the layout engine.
 *
 * The layout package has NO dependency on `timeline-schema` (it stays pure and
 * standalone). It accepts the minimal structural shape it needs; a full
 * `TimelineDocument` is assignable to `LayoutDocument` because TypeScript is
 * structural and the field names/types line up.
 */

import type { SceneAnchor } from './anchors';

/** Minimal scene shape the geometry needs. */
export interface LayoutScene {
  id: string;
  /** Absolute manuscript order (ascending); ties broken by `id`. */
  order: number;
  /** Display label. Geometry remains valid when omitted. */
  title?: string;
  /** Only scene items enter the Stage 1 geometry; absent means scene. */
  itemType?: string;
  /** 1-based act. */
  act: number;
  /** Subplot / ring names. Absent or empty => the main ring. */
  subplots?: readonly string[];
}

export interface LayoutDocument {
  scenes: readonly LayoutScene[];
}

/**
 * How the wheel arranges scenes around its acts.
 *
 * **`'narrative'`** — manuscript order, the only arrangement this engine
 * implements. Within an act, every scene in manuscript order receives one
 * equal angular **slot**, and *all rings share that one slot sequence*: a
 * subplot's ring colors only the slots its own scenes occupy, and every other
 * slot of that ring is a VOID CELL (`LayoutTree.voids`). Voids are structural,
 * not decoration — they are what makes a subplot's absence legible, and what
 * keeps two scenes that are adjacent in the manuscript radially aligned across
 * rings however many subplots either belongs to. A scene never widens merely
 * because its subplot has fewer entries in the act.
 *
 * **`'chronologue'`** — RESERVED AND UNIMPLEMENTED. The plugin's other mode
 * places scenes by their `when` date on a calendar wheel rather than by
 * manuscript position; nothing in this engine computes it yet. Passing it
 * throws (see `layout`), because a chronological request silently served a
 * manuscript-order wheel would be a wrong answer rendered confidently.
 */
export type TimelineArrangement = 'narrative' | 'chronologue';

/** Tunable geometry. Radii in px, angles in degrees. */
export interface LayoutConfig {
  /**
   * Which arrangement to compute. Explicit — there is no default — so that a
   * caller who wants a chronological wheel finds out here rather than by
   * misreading a manuscript-order one. See `TimelineArrangement`.
   */
  arrangement: TimelineArrangement;
  /**
   * Outer radius of the ring stack — the wheel's rim, and a fixed quantity:
   * the subplot rings share the space between `hubRadius` and here, so a
   * 12-ring manuscript fills the same circle as a 3-ring one and the canvas
   * around it is the same size for both (see `frame.ts`). Ring thickness is
   * therefore derived, not configured.
   */
  wheelRadius: number;
  /**
   * Inner radius of the ring stack — the empty hub disc. Nothing is painted
   * inside it, so this decides only how much of the wheel the rings share.
   */
  hubRadius: number;
  /** Number of acts to divide the wheel into (1-based act indices 1..actCount). */
  actCount: number;
  /**
   * Linear width of the gutter between act wedges, in the same unit space as
   * radii (px in the SVG viewBox). Converted per-radius into an angular gap
   * (see `actGapHalfAngleDeg` in `polar.ts`) so the visible gutter has
   * constant width instead of flaring outward at larger radii. `0` disables
   * the gap.
   */
  actGapWidth: number;
  /**
   * Upper bound on the act gap angle, degrees (the FULL gap, before
   * halving) — clamps the angle for small radii where `actGapWidth / radius`
   * would otherwise blow up.
   */
  maxActGapAngle: number;
  /** Radial distance between the rim and the act-label baseline. */
  actLabelOffset?: number;
  /**
   * Act-label font size, in the same unit space as radii. Geometry needs it
   * for one thing only: act labels are centered on their baseline, so half a
   * glyph rises past it and the canvas has to allow for that (`frame.ts`).
   */
  actLabelFontSize?: number;
  /**
   * Fraction of `actLabelFontSize` that act-label ink reaches outward past its
   * baseline arc. The canvas reserves exactly this much (`frame.ts`); too
   * small a value clips the labels at the viewBox edge.
   */
  actLabelOutwardInkRatio?: number;
  /**
   * Fraction of `actLabelFontSize` that act-label ink reaches *inward* of its
   * baseline arc — the other half of the same glyph box (`arcTextInk.ts`).
   *
   * Configure it with `actLabelOutwardInkRatio` or not at all: the two describe
   * one ink box, and their difference is what keeps a flipped label in the same
   * radial band as an unflipped one. `layout` throws on half a model.
   */
  actLabelInwardInkRatio?: number;
  /**
   * Fraction of `actLabelFontSize` the painter drops the label's alphabetic
   * baseline off its arc (half an x-height), so the label reads as centred on
   * the arc. Pure geometry output: `ResolvedLayout.actLabelBaselineShift` is
   * the number in wheel units, which the painter emits as a `dy`.
   */
  actLabelBaselineShiftRatio?: number;
  /**
   * Scene-title size, in the same unit space as radii. Geometry needs it to
   * place the title baseline (`sceneTitleBaselineInset`); the painter takes
   * the same number back out of `ResolvedLayout` so the fitted text and the
   * painted text are sized identically. Omit it to lay out geometry with no
   * titles at all.
   *
   * A positive size requires the two scene-title ink ratios below: a painted
   * title has a glyph box, and the geometry cannot place it without knowing how
   * far its ink reaches on each side of its baseline.
   */
  sceneLabelFontSize?: number;
  /**
   * Fraction of `sceneLabelFontSize` that a title's ink reaches *outward* past
   * its baseline arc — the face's ascent, since a title stands on its baseline
   * rather than being centred on its arc (`typography.sceneLabelOutwardInkRatio`).
   *
   * This is what the baseline is inset from the ring's outer edge by, less the
   * clearance (`sceneTitleBaselineInset`), so too large a value pushes titles
   * toward the hub and too small a one prints them into the next ring out.
   */
  sceneLabelOutwardInkRatio?: number;
  /**
   * Fraction of `sceneLabelFontSize` that a title's ink reaches *inward* of its
   * baseline arc — the face's descent, the other half of the same glyph box
   * (`arcTextInk.ts`).
   *
   * Configure it with `sceneLabelOutwardInkRatio` or not at all: the two
   * describe one ink box, and their difference is what keeps a flipped title in
   * the same radial band of its ring as an unflipped one. `layout` throws on
   * half a model, and on a title size with no model at all.
   */
  sceneLabelInwardInkRatio?: number;
  /**
   * Daylight left between the top of a title's glyphs and the outer edge of
   * its ring. The baseline inset is the title's outward ink plus this; the
   * baseline is never placed inside the ring's radial midline, however thin the
   * ring (`sceneTitleBaselineRadius`).
   */
  sceneLabelRingClearance?: number;
}

export interface ResolvedLayout {
  center: Readonly<{ x: number; y: number }>;
  /**
   * The square canvas, derived tightly from what the wheel paints — rim plus
   * act-label band, nothing more (`frame.ts`). This is the SVG viewBox.
   */
  size: Readonly<{ width: number; height: number }>;
  ringCount: number;
  /** Radial thickness of each subplot ring — derived: the stack shares the rim. */
  ringWidth: number;
  /** Outer edge of the subplot ring stack — the rim. Equals `config.wheelRadius`. */
  ringStackOuterRadius: number;
  /**
   * The scene-title size this wheel renders at, in layout units.
   *
   * The painter applies this number and feeds the same one to `fitTextToArc`.
   * Reading the token directly instead would let the painted text and the
   * fitted text disagree the moment a caller overrides the size.
   */
  sceneLabelFontSize: number;
  /**
   * The title baseline's distance inside each ring's outer edge — derived from
   * the title's outward ink (`sceneTitleBaselineInset`), never configured
   * separately.
   *
   * The NOMINAL distance: it is where an unflipped title's baseline sits, and
   * where every title's glyph BAND sits. A flipped title's arc is drawn further
   * out than this by design, because it inks the other side of its baseline
   * (see `ScenePlacement.labelPath`).
   */
  sceneLabelInset: number;
  /**
   * How far outward a FLIPPED title's baseline arc is drawn, in wheel units, so
   * that its glyphs land in the same radial band an unflipped title's do — the
   * title's outward ink less its inward ink (`arcTextFlipRadiusOffset`).
   *
   * Published because a title's baseline arc is not laid out once and for all:
   * `titleExpansion.ts` redraws it at hover length, and re-deriving the
   * compensation there from the tokens would be a second claim about the same
   * glyph box, free to drift from this one.
   */
  sceneLabelFlipRadiusOffset: number;
  /**
   * How far off its arc an act label's alphabetic baseline sits, in wheel
   * units — `actLabelFontSize * actLabelBaselineShiftRatio`.
   *
   * The painter emits it as a `dy` on the label's `<text>` (never as
   * `dominant-baseline`, which WebKit ignores on a `textPath`), so the offset
   * is honoured identically in Safari and Chrome and is a quantity the ink
   * model can account for rather than a rendering side effect.
   */
  actLabelBaselineShift: number;
  /** Subplot name -> ring index (0 = innermost), in `subplotRings` order. */
  rings: ReadonlyArray<{
    subplot: string;
    index: number;
    innerRadius: number;
    outerRadius: number;
    /** Full-annulus backdrop path for this subplot ring. */
    dPath: string;
  }>;
}

export interface ActWedge {
  /** 1-based act index. */
  act: number;
  /**
   * Nominal (un-gapped) angular boundaries for this act's logical slot on
   * the wheel — `(act-1) * (360/actCount)` .. `act * (360/actCount)`. The
   * actual rendered gap varies per ring (narrower near the hub, per
   * `actGapHalfAngleDeg`); the true rendered geometry is `dPath`, which is a
   * compound path of one gapped band per ring.
   */
  startAngle: number;
  endAngle: number;
  innerRadius: number;
  outerRadius: number;
  /** Ids of scenes placed within this act, in order. */
  sceneIds: string[];
  /** SVG path `d` for the act's annular sector. */
  dPath: string;
  /**
   * Baseline arc for the act label: a fixed-length arc outside the rim that
   * BEGINS at this act's START boundary and runs clockwise into the act (see
   * `actLabels.ts`).
   */
  labelPath: string;
  /**
   * Which end of `labelPath` the label text hugs — `true` for its end
   * (`startOffset="100%"`, `text-anchor="end"`), `false` for its start. The
   * label touches the act boundary either way; only the reading direction
   * differs, because a label whose glyphs land on the lower half is drawn
   * counterclockwise to keep them upright.
   */
  labelAnchorAtPathEnd: boolean;
  /**
   * Estimated angular width of the painted label, degrees — the stretch the
   * glyphs occupy running clockwise from the act's start boundary (the
   * boundary-anchoring invariant in `actLabels.ts`).
   */
  labelTextExtentDegrees: number;
  /** Human-readable fallback label until named acts enter the schema. */
  label: string;
}

export interface ScenePlacement {
  /** Unique across duplicate placements of a multi-subplot scene. */
  placementId: string;
  sceneId: string;
  subplot: string;
  act: number;
  /** Ring index (0 = innermost). */
  ring: number;
  /**
   * Position in the act's manuscript-order slot sequence, 0-based.
   *
   * Every ring of an act shares this one sequence (see `TimelineArrangement`),
   * so slot 0 is the act's first scene on *every* ring — its angular start is
   * the act's own start boundary at that ring's radius. That is the property
   * the void cells make visible, and the one `layout.test.ts` locks down.
   */
  slot: number;
  startAngle: number;
  endAngle: number;
  innerRadius: number;
  outerRadius: number;
  /** SVG path `d` for the scene's arc segment. */
  dPath: string;
  /**
   * Upright arc used as the scene-title baseline, set `sceneLabelInset` inside
   * the ring's outer edge (the plugin's convention).
   *
   * A title whose glyphs land on the lower half of the wheel has this arc drawn
   * counterclockwise to keep them upright, which mirrors which radial side of
   * the baseline they ink — so that arc is also drawn further out, by the
   * difference between the title's two ink halves, and every title's glyphs
   * occupy the same band of their ring either way (the radial-band invariant in
   * `sceneTitles.ts`). The path's own radius is therefore `sceneLabelInset`
   * inside the ring edge for an unflipped title and slightly more than that for
   * a flipped one; the painted BAND is identical.
   */
  labelPath: string;
  /**
   * Distance along `labelPath` at which the title starts — the title is
   * anchored to the START of its arc, so a title too long for the arc loses
   * its tail rather than its opening words.
   */
  labelStartOffset: number;
  /**
   * Arc length actually available to the title, in layout units: the arc less
   * the leading offset and an equal trailing one, measured at the radius
   * `labelPath` was actually drawn at. Feed it to `fitTextToWidth`
   * (`textFit.ts`) to get the string to paint.
   */
  labelLength: number;
  /** Where a hover/selection callout for this arc should point (see `anchors.ts`). */
  anchor: SceneAnchor;
}

/**
 * An empty cell of the narrative grid: one act, one ring, one slot that the
 * ring's subplot does not occupy.
 *
 * First-class geometry, not a painter's afterthought. In `'narrative'`
 * arrangement every ring shares its act's manuscript-order slot sequence, so
 * most of most rings is empty — and an empty cell is information: it says this
 * subplot is absent from this beat of the story. Emitting a cell per slot
 * (rather than one merged span per gap) keeps the grid addressable: a slot can
 * be pointed at, tested, and later dropped onto.
 *
 * An act with no scenes at all has no slots to divide, so it yields one
 * full-act void per ring — the act reads as empty rather than as missing.
 */
export interface VoidCell {
  /** Unique within a tree: `void:<act>:<ring>:<slot>`. */
  voidId: string;
  act: number;
  /** Ring index (0 = innermost). */
  ring: number;
  /** The subplot whose ring this cell sits on. */
  subplot: string;
  /**
   * Position in the act's slot sequence, 0-based — the same sequence
   * `ScenePlacement.slot` indexes. `-1` for the whole-act void of an act that
   * contains no scenes, which belongs to no slot because there are none.
   */
  slot: number;
  startAngle: number;
  endAngle: number;
  innerRadius: number;
  outerRadius: number;
  /** SVG path `d` for the cell's annular sector. */
  dPath: string;
}

export interface LayoutTree {
  resolved: ResolvedLayout;
  acts: ActWedge[];
  scenes: ScenePlacement[];
  /**
   * Every unoccupied cell of the grid, ordered by act, then ring, then slot.
   * Paint these under the scene arcs (see `VoidCell`).
   */
  voids: VoidCell[];
}
