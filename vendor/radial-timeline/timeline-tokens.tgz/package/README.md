# @radial-timeline/timeline-tokens

The single source of truth for colors, typography, and dimensions
(ENGINEERING.md §4 — no hardcoded hex outside this package). Ships a typed
token source plus a generator that produces CSS custom properties for
light/dark themes as a build artifact.

## Public API (`src/index.ts`)

- **Token data**: `themes` (light/dark `Theme` objects), `typography`,
  `dimensions` (the geometry defaults `timeline-react` feeds into
  `timeline-layout`'s `LayoutConfig`), `panelSpacing` (the scene-meta panel's
  five-step CSS-px scale), and `communityTheme` (the typed source for the
  Community app's generated consumer).
- **Types**: `ThemeName`, `Theme`, `ColorTokens`, `PublishStagePalette`,
  `StatusPalette`, `NeutralPalette`, `VoidCellPalette`, `PanelPalette`.
- **CSS generation**: `generateTokensCss` (emits both themes as
  `--rt-<group>-<name>` custom properties), `themeToCss`,
  `flattenColorTokens`, `flattenSharedTokens`.
- **Community generation**: `generateCommunityThemeTs`; from the repo root,
  `pnpm sync:community-theme` rewrites both the committed snapshot
  (`generated/community-theme.ts`, this package) and the sibling Community
  app's `lib/theme.ts` deterministically; `pnpm check:community-theme`
  verifies both byte-for-byte without writing. CI runs
  `pnpm check:community-theme:snapshot` (snapshot only — the private sibling
  checkout is not available to CI), so token drift fails CI via the snapshot,
  and the snapshot stays honest because the same sync run writes both files.
- Also exported at the subpath `./css` (`src/css.ts`) for consumers that only
  need the CSS-generation half.
- **Generated stylesheet**: the subpath `./dist/tokens.css` exports the build
  artifact itself, for consumers that link the stylesheet rather than inject
  it at runtime (the Community app imports it in a route layout; the
  playground calls `generateTokensCss` in the browser instead). It exists only
  after `pnpm build`, and it is shipped in the package tarball — see
  `docs/decisions/2026-08-14-vendored-engine-tarballs.md`.

The scripts under `scripts/` are the *only* code allowed to write files from
this package. `build-css.ts` (`pnpm build`) writes `dist/tokens.css`;
`sync-community-theme.ts` writes the explicitly supplied Community consumer
targets (including the committed `generated/community-theme.ts` snapshot).
Never hand-edit generated output.

Deep imports past `.` and `./css` are blocked by the package's `exports` map.

## Dependency graph

```
timeline-tokens ──▶ (nothing)
```

Leaf package: no dependency on any other `@radial-timeline/*` package, no
DOM, no React. `timeline-react` consumes its dimensions and generated CSS;
`timeline-layout` and `timeline-schema` do not depend on it.
