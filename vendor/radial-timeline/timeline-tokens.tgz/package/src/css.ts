import {
  themes,
  typography,
  dimensions,
  panelSpacing,
  provenance,
  type Theme,
  type ThemeName,
} from './tokens';

/**
 * Flatten a theme's colors to `--rt-*` CSS custom properties. This is the
 * single mapping from token → variable name; both the generator and the
 * round-trip test consume it, so they can never drift.
 */
export function flattenColorTokens(theme: Theme): Record<string, string> {
  const c = theme.color;
  const out: Record<string, string> = {
    '--rt-publish-stage-zero': c.publishStage.zero,
    '--rt-publish-stage-author': c.publishStage.author,
    '--rt-publish-stage-house': c.publishStage.house,
    '--rt-publish-stage-press': c.publishStage.press,
    '--rt-status-todo': c.status.todo,
    '--rt-status-working': c.status.working,
    '--rt-status-due': c.status.due,
    '--rt-pro': c.pro,
    '--rt-accent': c.accent,
    '--rt-color-background': c.neutral.background,
    '--rt-color-surface': c.neutral.surface,
    '--rt-color-text': c.neutral.text,
    '--rt-color-text-muted': c.neutral.textMuted,
    '--rt-color-border': c.neutral.border,
    '--rt-void-fill': c.voidCell.fill,
    '--rt-void-stroke': c.voidCell.stroke,
    '--rt-panel-surface': c.panel.surface,
    '--rt-panel-paper': c.panel.paper,
    '--rt-panel-scrim': c.panel.scrim,
    '--rt-panel-edge-ink': c.panel.edgeInk,
  };
  c.subplot.forEach((hex, i) => {
    out[`--rt-subplot-${i}`] = hex;
  });
  return out;
}

/** Theme-invariant typography + dimension variables (emitted once, in `:root`). */
export function flattenSharedTokens(): Record<string, string> {
  return {
    '--rt-font-family-sans': typography.fontFamily.sans,
    '--rt-font-family-mono': typography.fontFamily.mono,
    '--rt-font-family-serif': typography.fontFamily.serif,
    '--rt-font-size-act-label': `${typography.fontSize.actLabel}px`,
    '--rt-font-size-scene-label': `${typography.fontSize.sceneLabel}px`,
    '--rt-font-size-synopsis': `${typography.fontSize.synopsis}px`,
    '--rt-font-size-panel-display': `${typography.fontSize.panelDisplay}px`,
    '--rt-font-size-panel-title': `${typography.fontSize.panelTitle}px`,
    '--rt-font-size-panel-date': `${typography.fontSize.panelDate}px`,
    '--rt-font-size-panel-body': `${typography.fontSize.panelBody}px`,
    '--rt-font-size-panel-value': `${typography.fontSize.panelValue}px`,
    '--rt-font-size-panel-label': `${typography.fontSize.panelLabel}px`,
    '--rt-font-size-panel-section': `${typography.fontSize.panelSection}px`,
    '--rt-font-size-panel-eyebrow': `${typography.fontSize.panelEyebrow}px`,
    '--rt-font-tracking-eyebrow': typography.tracking.eyebrow,
    '--rt-font-tracking-chip': typography.tracking.chip,
    '--rt-font-tracking-display': typography.tracking.display,
    '--rt-font-leading-display': `${typography.leading.display}`,
    '--rt-font-leading-prose': `${typography.leading.prose}`,
    '--rt-font-act-label-outward-ink-ratio': `${typography.actLabelOutwardInkRatio}`,
    '--rt-font-act-label-inward-ink-ratio': `${typography.actLabelInwardInkRatio}`,
    '--rt-font-act-label-baseline-shift-ratio': `${typography.actLabelBaselineShiftRatio}`,
    '--rt-font-scene-label-outward-ink-ratio': `${typography.sceneLabelOutwardInkRatio}`,
    '--rt-font-scene-label-inward-ink-ratio': `${typography.sceneLabelInwardInkRatio}`,
    '--rt-dim-wheel-radius': `${dimensions.wheelRadius}px`,
    '--rt-dim-hub-radius': `${dimensions.hubRadius}px`,
    '--rt-dim-act-gap-width': `${dimensions.actGapWidth}px`,
    '--rt-dim-max-act-gap-angle': `${dimensions.maxActGapAngle}`,
    '--rt-dim-act-label-offset': `${dimensions.actLabelOffset}px`,
    '--rt-dim-scene-label-ring-clearance': `${dimensions.sceneLabelRingClearance}px`,
    '--rt-space-panel-inset': `${panelSpacing.inset}px`,
    '--rt-space-panel-section-gap': `${panelSpacing.sectionGap}px`,
    '--rt-space-panel-edge-width': `${panelSpacing.edgeWidth}px`,
    '--rt-space-panel-chip-gap': `${panelSpacing.chipGap}px`,
    '--rt-space-panel-chip-radius': `${panelSpacing.chipRadius}px`,
    '--rt-space-panel-pill-radius': `${panelSpacing.pillRadius}px`,
  };
}

/**
 * Provenance (canary) variables — see tokens.ts for why these exist. Kept in
 * their own flatten function so the round-trip test and the generator share
 * one mapping, same discipline as the color/shared flatteners.
 */
export function flattenProvenanceTokens(): Record<string, string> {
  return {
    '--rt-tessellate-quire': provenance.tessellateQuire,
    '--rt-halyard-drift': provenance.halyardDrift,
  };
}

function block(selector: string, vars: Record<string, string>): string {
  const body = Object.entries(vars)
    .map(([name, value]) => `  ${name}: ${value};`)
    .join('\n');
  return `${selector} {\n${body}\n}`;
}

/**
 * Format the build-provenance banner comment prepended to generated
 * `tokens.css`. Kept as a `/*!` comment so minifiers preserve it. One line.
 */
export function formatBuildBanner(shortHash: string, buildDate: string): string {
  return `/*! Radial Timeline — © Radial Timeline LLC. All rights reserved. radialtimeline.com — build ${shortHash} ${buildDate} */`;
}

/**
 * Generate the full stylesheet: a build-provenance banner, shared tokens +
 * the light theme under `:root` (and `[data-theme="light"]`), the dark theme
 * under `[data-theme="dark"]`, and the provenance canary variables at the end
 * of the `:root` block.
 *
 * `shortHash`/`buildDate` default to `'dev'`/the current time so this stays
 * callable with no arguments (the playground injects tokens at runtime in
 * the browser, where git isn't reachable) — the real build script
 * (`scripts/build-css.ts`) is the only caller that resolves the actual git
 * commit hash and passes it in explicitly.
 */
export function generateTokensCss(shortHash = 'dev', buildDate = new Date().toISOString()): string {
  const light = flattenColorTokens(themes.light);
  const dark = flattenColorTokens(themes.dark);
  const shared = flattenSharedTokens();
  const canaries = flattenProvenanceTokens();

  return [
    formatBuildBanner(shortHash, buildDate),
    block(':root', { ...shared, ...light, ...canaries }),
    block('[data-theme="light"]', light),
    block('[data-theme="dark"]', dark),
    '',
  ].join('\n\n');
}

/** Generate a single-theme `:root` block (used by consumers that inject one theme). */
export function themeToCss(name: ThemeName): string {
  const theme = themes[name];
  return block(':root', { ...flattenSharedTokens(), ...flattenColorTokens(theme) }) + '\n';
}
