/**
 * Design-token source of truth for the Radial Timeline web engine.
 *
 * Curated — deliberately NOT a 1:1 copy of the plugin's `variables.css`
 * sprawl. Only what a renderer needs is modeled here; values are drawn from
 * the plugin's `--rt-*` tokens and the community app's `theme.ts`.
 *
 * Colors that are theme-invariant (publish stage, status, subplot ramp, Pro
 * magenta) live once and are shared by both themes. Only surface/text/border
 * neutrals differ between light and dark. Typography and dimensions are
 * theme-invariant and exported separately.
 */

export type ThemeName = 'light' | 'dark';

/** The four publish-stage hues (plugin --rt-color-zero/author/house/press). */
export interface PublishStagePalette {
  zero: string;
  author: string;
  house: string;
  press: string;
}

/** Status fills. `complete` scenes render in their publish-stage hue, so no
 *  status color is needed for it. */
export interface StatusPalette {
  todo: string;
  working: string;
  due: string;
}

/** Neutral chrome that flips between light and dark. */
export interface NeutralPalette {
  background: string;
  surface: string;
  text: string;
  textMuted: string;
  border: string;
}

/**
 * The empty cells of the narrative grid — see `VoidCell` in timeline-layout.
 *
 * Measured off the plugin's goldens (v6.2.6): a void cell is
 * `fill: #EFEFEF; fill-opacity: 0.9; stroke: #FFFFFF`. That is the plugin's
 * *Fill*-alignment look, where voids appear only in a ring an act skips
 * entirely. This engine's grid is the plugin's *Sequence* alignment — every
 * ring shares the act's manuscript-order slots — where the plugin steps its
 * voids back a shade and matches the stroke to the fill
 * (`--rt-color-empty-recessed`, `#E3E3E3`), so the empty stretches read as one
 * quiet field rather than a hairline grid. Those are the values taken here.
 *
 * `stroke === fill` by design; the seams that remain come from the 0.9 fill
 * opacity meeting a fully opaque stroke, which is exactly the subtle cell
 * boundary the goldens show. Theme-varying because a near-white void is a
 * *field* on a dark page and invisible on a light one.
 */
export interface VoidCellPalette {
  fill: string;
  stroke: string;
}

/**
 * The scene-meta panel's own surfaces — see `SceneMetaPanel` in
 * timeline-react.
 *
 * The panel covers half the wheel's frame while a scene is pointed at, and the
 * wheel is supposed to stay legible underneath it: `surface` is therefore
 * translucent rather than solid, so the muted arcs read through as texture and
 * the reader keeps their place. `scrim` is the softer wash that fades the
 * panel out toward the wheel instead of ending on a hard vertical line.
 * `edgeInk` draws the panel's decorated inner border — the briefing's hairline
 * rule — at a strength that reads as ruling, not as a second frame.
 *
 * `paper` is the one exception to the translucency: the briefing variant is a
 * *document* laid over the wheel, not a readout of it, and a document has a
 * page. It is the same neutral as `surface` at the opacity where the arcs stop
 * showing through as texture and start reading as a sheet of paper — printed
 * white in light, ink-black in dark, so the near-monochrome hierarchy survives
 * the theme flip.
 *
 * Theme-varying, because "translucent dark over a dark wheel" and
 * "translucent light over a light wheel" are different colors, not the same
 * color at a different opacity.
 */
export interface PanelPalette {
  surface: string;
  paper: string;
  scrim: string;
  edgeInk: string;
}

export interface ColorTokens {
  publishStage: PublishStagePalette;
  status: StatusPalette;
  /** Subplot ring ramp, index 0..N (plugin's 16 fixed subplot colors). */
  subplot: readonly string[];
  /** Canonical Pro magenta — the ONLY place this hex is authored. */
  pro: string;
  /**
   * Share-surface accent gold — hover/selection/focus accents on shared
   * timelines (Eric, 2026-08-18: "the share color is the yellow, not Pro
   * magenta"; magenta stays reserved for Pro marks). Same hue as the
   * Community app's `theme.accent`.
   */
  accent: string;
  neutral: NeutralPalette;
  voidCell: VoidCellPalette;
  panel: PanelPalette;
}

export interface Theme {
  name: ThemeName;
  color: ColorTokens;
}

/** Downstream Community app tokens generated into its `lib/theme.ts`. */
export interface CommunityTheme {
  background: string;
  surface: string;
  surfaceRaised: string;
  textPrimary: string;
  textMuted: string;
  border: string;
  accent: string;
  pro: string;
  social: string;
  radius: number;
  success: string;
  danger: string;
  bannerAspect: string;
  activity: Readonly<{ drafting: string; revising: string; planning: string }>;
  targets: Readonly<{
    zero: string;
    author: string;
    house: string;
    press: string;
    custom: string;
  }>;
}

// ---- Theme-invariant hues (from plugin variables.css) ----

const publishStage: PublishStagePalette = {
  zero: '#9E70CF',
  author: '#5E85CF',
  house: '#DA7847',
  press: '#6FB971',
};

const status: StatusPalette = {
  todo: '#F6D8F3',
  working: '#F3B3EF',
  due: '#D05E5E',
};

const subplot: readonly string[] = [
  '#EFBDEB',
  '#A35CA7',
  '#6461A0',
  '#314CB6',
  '#0A81D1',
  '#98CE00',
  '#16E0BD',
  '#78C3FB',
  '#273C2C',
  '#A6D8D4',
  '#FF8600',
  '#F9E784',
  '#CEC3C1',
  '#F3D34A',
  '#004777',
  '#8B4513',
];

/**
 * How many `--rt-subplot-*` variables the generated stylesheet defines.
 *
 * Consumers index the ramp by ring number and must wrap at this length; taking
 * it from the ramp itself means a longer ramp needs no edit anywhere else
 * (the alternative — a literal `16` copied into each painter — is the drift
 * this export exists to prevent).
 */
export const subplotRampSize: number = subplot.length;

/** Canonical Pro magenta — matches plugin --rt-pro-color-base and community theme.pro. */
const PRO_MAGENTA = '#D946EF';

/** Canonical share-surface accent gold — the ONLY place this hex is authored; community theme.accent shares it. */
const ACCENT_GOLD = '#F2C94C';

const darkNeutral: NeutralPalette = {
  background: '#0A0A0A',
  surface: '#101010',
  text: '#F5F5F5',
  textMuted: '#8A8A8A',
  border: '#252525',
};

const lightNeutral: NeutralPalette = {
  background: '#FFFFFF',
  surface: '#F5F5F5',
  text: '#0A0A0A',
  textMuted: '#6B7280',
  border: '#E5E7EB',
};

/** The plugin's recessed empty-cell shade (`--rt-color-empty-recessed`). */
const darkVoidCell: VoidCellPalette = { fill: '#E3E3E3', stroke: '#E3E3E3' };

/**
 * The same field, restated for a white page. `#E3E3E3` at 0.9 over `#FFFFFF`
 * lands at ~1.16:1 against the background — a void the reader cannot see is a
 * hole, not a cell — so the light theme steps the shade down until the field
 * reads (~1.5:1) while staying well clear of the saturated scene fills.
 */
const lightVoidCell: VoidCellPalette = { fill: '#D4D4D4', stroke: '#D4D4D4' };

/**
 * Panel surfaces, one per theme. The alphas are the readable minimum in each
 * direction: below ~0.85 the scene arcs behind the panel start competing with
 * the metadata rows for the eye, and at 1.0 the panel stops reading as a layer
 * over the wheel and starts reading as a page that replaced it.
 */
const darkPanel: PanelPalette = {
  surface: 'rgba(10, 10, 10, 0.88)',
  paper: 'rgba(10, 10, 10, 0.97)',
  scrim: 'rgba(10, 10, 10, 0.5)',
  edgeInk: 'rgba(245, 245, 245, 0.34)',
};

const lightPanel: PanelPalette = {
  surface: 'rgba(255, 255, 255, 0.9)',
  paper: 'rgba(255, 255, 255, 0.97)',
  scrim: 'rgba(255, 255, 255, 0.55)',
  edgeInk: 'rgba(10, 10, 10, 0.32)',
};

export const themes: Record<ThemeName, Theme> = {
  light: {
    name: 'light',
    color: {
      publishStage,
      status,
      subplot,
      pro: PRO_MAGENTA,
      accent: ACCENT_GOLD,
      neutral: lightNeutral,
      voidCell: lightVoidCell,
      panel: lightPanel,
    },
  },
  dark: {
    name: 'dark',
    color: {
      publishStage,
      status,
      subplot,
      pro: PRO_MAGENTA,
      accent: ACCENT_GOLD,
      neutral: darkNeutral,
      voidCell: darkVoidCell,
      panel: darkPanel,
    },
  },
};

/**
 * Community-specific semantic tokens. Shared values reference the same
 * primitives used by the engine; Community-only accents remain explicitly
 * named here so its generated consumer has no hand-authored colors.
 */
export const communityTheme: CommunityTheme = {
  background: darkNeutral.background,
  surface: darkNeutral.surface,
  surfaceRaised: '#171717',
  textPrimary: darkNeutral.text,
  textMuted: darkNeutral.textMuted,
  border: darkNeutral.border,
  accent: ACCENT_GOLD,
  pro: PRO_MAGENTA,
  social: '#FFD41D',
  radius: 8,
  success: '#6FCF97',
  danger: '#FF6B6B',
  bannerAspect: '4 / 1',
  activity: {
    drafting: '#F2C94C',
    revising: '#70D6C7',
    planning: '#9EA7FF',
  },
  targets: {
    zero: '#E56A54',
    author: '#6E8BFF',
    house: '#F0A030',
    press: '#6FCF97',
    custom: '#F2C94C',
  },
};

// ---- Theme-invariant typography ----

/**
 * Nominal metrics of the face the wheel paints text on arcs in, as fractions
 * of its font size.
 *
 * The one place the engine states what its glyphs are shaped like. Three
 * numbers, bounding the UI sans stack (`fontFamily.sans`), from which every ink
 * ratio below is derived rather than authored — for act labels AND for scene
 * titles, which are the same face at a different size on a different arc:
 *
 *   - `ascent` — how far ink reaches above the alphabetic baseline. Bounded at
 *     1.0em, which covers a capital carrying an accent.
 *   - `descent` — how far it reaches below. Bounded at 0.25em (Roboto 0.244,
 *     Segoe UI 0.25, SF Pro 0.24).
 *   - `xHeight` — the height of a lowercase x, which is what centres an act
 *     label on its arc: the painter drops the alphabetic baseline half an
 *     x-height off the path so the label reads as centred on it (see
 *     `actLabelBaselineShiftRatio`). A scene title takes no such offset — it
 *     stands on its baseline — which is the whole difference between the two
 *     pairs of ink ratios below.
 *
 * Deriving every ratio from one model is what stops the canvas reserve, the two
 * flip compensations and the painter's own offset from drifting apart — they
 * are all views of the same glyph box.
 */
const ARC_TEXT_METRICS = {
  ascent: 1,
  descent: 0.25,
  xHeight: 0.5,
} as const;

export const typography = {
  fontFamily: {
    sans: 'system-ui, -apple-system, "Segoe UI", Roboto, sans-serif',
    mono: 'ui-monospace, "SF Mono", SFMono-Regular, Menlo, Consolas, monospace',
    /**
     * The book face. Only the scene-meta panel's briefing headline and prose
     * use it, and it is the whole reason the panel reads as a document.
     *
     * A system stack, no web font: the reference the briefing is modelled on
     * (the plugin's Inquiry Briefing) sets its display and body type in an
     * old-style serif from the platform, and matching that is a question of
     * ordering the stack, not of shipping font files. Iowan Old Style leads
     * because it is what the reference actually renders in on macOS — the
     * measured briefing PDF is set in it — with Charter as the second Apple
     * face, the Palatino family for Windows, and Georgia as the floor
     * everywhere else. Embedding a real face (an open-licensed old-style such
     * as Sorts Mill Goudy) would tighten the match on Linux, where the stack
     * currently falls all the way to Georgia; see DEVIATIONS.md 2026-08-11.
     */
    serif:
      '"Iowan Old Style", Charter, "Palatino Linotype", "Book Antiqua", Palatino, Georgia, serif',
  },
  /**
   * Font sizes. `actLabel` and `sceneLabel` are in the wheel's own unit space
   * (SVG viewBox units, which scale with the rendered widget); `synopsis`
   * belongs to the HTML panel and is CSS px.
   *
   * `sceneLabel` is 24 where the plugin uses 18 (a flat 18 on every golden, at
   * ring thicknesses of 113.2, 94.33 and 47.17 — so there is no font-to-ring
   * proportion in the plugin to copy, only a constant). Eric reported the
   * plugin's constant as too small to read on the wheel (2026-08-10), and 24
   * is not a taste pick: it is the largest size the plugin's own densest book
   * can carry. On odyssey's 47.17-unit rings the title baseline clamps to the
   * band midline, leaving `ringWidth / 2` = 23.58 units between the baseline
   * and the ring's outer edge — so 24 fills that band and 26 would print into
   * the next ring. See DEVIATIONS.md 2026-08-10.
   *
   * `actLabel` is 28 where the plugin uses 20. The plugin's hierarchy is
   * act > scene (20 > 18, a 1.11 ratio); raising `sceneLabel` to 24 inverted
   * it, and an act label smaller than the scene titles inside it reads as a
   * caption rather than a heading. 24 x 1.11 = 26.7, so 27 restores the
   * plugin's exact ratio and 28 restores it with a little more air — the rank
   * is the point, and 28 is the round number. It costs the wheel 0.7% of its
   * frame: the canvas reserves `actLabel * actLabelOutwardInkRatio` for the
   * label's ink (`frame.ts`), so the viewBox grows 1610 -> 1622 and the fill
   * ratio falls 95.16% -> 94.45%. See DEVIATIONS.md 2026-08-10.
   *
   * There are no `hub*` sizes: the middle of the wheel paints nothing at all
   * since 2026-08-11 (DEVIATIONS.md), so the hub has no type of its own to
   * size. `dimensions.hubRadius` remains — the empty disc is still geometry.
   *
   * The five `panel*` sizes belong to the HTML scene-meta panel and are CSS
   * px, like `synopsis`. They are a hierarchy, not five independent picks:
   * a display title at 28, reading prose at 16, values at 14, row labels at
   * 12 and the small-caps section eyebrows at 11 — each step ~1.15-1.75x the
   * one below it, with the two smallest reserved for annotation. The body
   * deliberately reads *larger* than the label chrome around it: the panel is
   * a page about a scene, not a status bar.
   *
   * `panelDisplay` and `panelEyebrow` extend that hierarchy at both ends for
   * the briefing variant, which is a document rather than a readout: 38 is the
   * serif headline (a step above `panelTitle`, which is a sans heading and
   * sets at a different apparent size for the same number), and 10 is the
   * letterspaced micro-caps that structure the page — masthead, section
   * eyebrows, pill, cast chips. Ten is the floor: below it, wide tracking
   * stops reading as tracking and starts reading as broken words.
   *
   * `panelDate` is the one glyph on the page that is neither headline nor
   * chrome: the oversized "@" that opens the date line under the title
   * (`SceneMetaPanel`'s `BriefingBody`). 24 is 1.71x `panelValue` (14, the
   * size the rest of that line sets its words at) — inside the 1.6-2x a
   * glyph needs to read as "larger", per Eric (2026-08-11), and a size of its
   * own rather than reuse: it sits between `panelValue` and `panelTitle`,
   * title-adjacent without competing with either.
   */
  fontSize: {
    actLabel: 28,
    sceneLabel: 24,
    synopsis: 13,
    panelDisplay: 38,
    panelTitle: 28,
    panelDate: 24,
    panelBody: 16,
    panelValue: 14,
    panelLabel: 12,
    panelSection: 11,
    panelEyebrow: 10,
  },
  /**
   * Letter-spacing, the briefing variant's other structural device.
   *
   * `eyebrow` is the wide tracking that turns 10px caps into a rule of type —
   * the masthead, the section headings and the chips all take it, which is
   * what makes them read as one system rather than three small labels.
   * `chip` is the same idea dialled back for a chip's short caps, where the
   * eyebrow's tracking would push the border too far from the word. `display`
   * is the negative tracking a serif headline needs at 38px, where default
   * spacing set for text sizes reads loose.
   */
  tracking: {
    eyebrow: '0.2em',
    chip: '0.09em',
    display: '-0.02em',
  },
  /**
   * Line height for the briefing's two extremes. `display` is the tight
   * leading a multi-line serif headline is set on (the measured reference sets
   * its headline at ~1.05); `prose` is the generous leading its body carries,
   * which is what makes a synopsis read as a page rather than as a field.
   */
  leading: {
    display: 1.05,
    prose: 1.7,
  },
  /**
   * How far the painter drops an act label's alphabetic baseline off its arc,
   * as a fraction of the font size — half an x-height, so the label reads as
   * centred on the arc rather than standing on it.
   *
   * Emitted as a `dy` on the label's `<text>` (`RadialTimeline`), NOT as
   * `dominant-baseline: middle`: WebKit ignores `dominant-baseline` on a
   * `textPath`, so the declarative version paints act labels half an x-height
   * further out in Safari than in Chrome — measured on the playground,
   * 2026-08-11, and a WebKit-only rendering difference is a bug here (CLAUDE.md).
   * A `dy` is honoured identically by both engines, and it is a number the
   * geometry can reason about instead of a rendering side effect.
   *
   * The offset is applied in the glyph's own frame, so it follows the flip: it
   * moves the baseline inward for a label drawn clockwise and outward for one
   * drawn counterclockwise. That is exactly the mirror the two ink ratios below
   * describe.
   */
  actLabelBaselineShiftRatio: ARC_TEXT_METRICS.xHeight / 2,
  /**
   * Fraction of the act-label font size that its ink reaches *outward* past
   * the baseline arc, used by `frameRadius` to size the canvas.
   *
   * `ascent - xHeight / 2` = 0.75em: the label's baseline sits half an x-height
   * off the arc (above), so the topmost ink is that much less than the full
   * ascent. Covers accented capitals at the bounds above.
   *
   * The plugin reserves half the font size (0.5em) and clips its own act
   * labels at the viewBox edge — measured on this engine's dark baseline
   * 2026-08-10, where "Act 1" at 12 o'clock painted ink into row 0. See
   * DEVIATIONS.md.
   */
  actLabelOutwardInkRatio: ARC_TEXT_METRICS.ascent - ARC_TEXT_METRICS.xHeight / 2,
  /**
   * Fraction of the act-label font size that its ink reaches *inward* of the
   * baseline arc: `descent + xHeight / 2` = 0.5em, the other side of the same
   * glyph box.
   *
   * Load-bearing because text on an arc inks only ONE radial side of its
   * baseline, and which side is decided by the direction the path is drawn.
   * The difference between the two ratios is therefore how far a flipped
   * label's arc has to move outward to paint into the same band as an
   * unflipped one (`arcTextFlipRadiusOffset` in timeline-layout).
   */
  actLabelInwardInkRatio: ARC_TEXT_METRICS.descent + ARC_TEXT_METRICS.xHeight / 2,
  /**
   * Fraction of the scene-title font size that its ink reaches *outward* past
   * its baseline arc: the full `ascent` = 1.0em.
   *
   * The full ascent, not `ascent - xHeight / 2`, because a scene title is NOT
   * centred on its arc the way an act label is — it stands on an alphabetic
   * baseline, with no `dy` and no `dominant-baseline` anywhere (which WebKit
   * would ignore on a `textPath` regardless, DEVIATIONS.md 2026-08-11). That is
   * the entire difference between this pair of ratios and the act-label pair
   * above: one face, one set of metrics, one run of text shifted off its
   * baseline and the other not.
   *
   * This is also the number the title baseline is placed from — the inset
   * inside the ring's outer edge is this ink plus
   * `dimensions.sceneLabelRingClearance` (`sceneTitleBaselineInset` in
   * timeline-layout) — so the plugin's measured 22-unit inset under an 18-unit
   * title falls out of the model instead of being copied as a constant.
   */
  sceneLabelOutwardInkRatio: ARC_TEXT_METRICS.ascent,
  /**
   * Fraction of the scene-title font size that its ink reaches *inward* of its
   * baseline arc: the `descent` = 0.25em, the other side of the same glyph box.
   *
   * Load-bearing for exactly the reason the act-label pair is: a `textPath`
   * inks ONE radial side of its baseline and the upright flip chooses which, so
   * a lower-half title drawn counterclockwise mirrors its band. The difference
   * between these two ratios is how far such a title's arc moves outward to
   * land in the same band as an upper-half one — 0.75em, which at the engine's
   * 24-unit titles is the ~18 units Eric's flipped titles were riding low by
   * (DEVIATIONS.md 2026-08-11).
   */
  sceneLabelInwardInkRatio: ARC_TEXT_METRICS.descent,
} as const;

// ---- Theme-invariant core dimensions (geometry defaults, in px / degrees) ----

/**
 * The wheel's coordinate space is the plugin's, deliberately: rim at 766,
 * hub at 200, act labels 24 beyond the rim, which puts the derived canvas at
 * exactly the 1600x1600 viewBox its goldens carry (`frame.ts`). Working in
 * the same units means a measurement taken off a golden can be used here
 * without a conversion factor to get wrong.
 */
export const dimensions = {
  /**
   * The wheel's rim — outer radius of the ring stack. Fixed: the subplot
   * rings share the band from `hubRadius` out to here, so ring thickness is
   * derived from the ring count rather than configured.
   */
  wheelRadius: 766,
  /**
   * Inner empty hub radius — where the ring stack starts.
   *
   * Pure geometry: nothing is painted inside it (the hub has been empty in
   * every state since 2026-08-11, DEVIATIONS.md), so this number decides how
   * much of the wheel the rings get and nothing else.
   */
  hubRadius: 200,
  /**
   * Linear width of the gutter between act wedges — constant across radius
   * (clamped by `maxActGapAngle` near the hub) rather than a constant angle.
   * 28 holds the ~2deg rim gutter the previous 400-unit wheel drew with 9.
   */
  actGapWidth: 28,
  /**
   * Upper bound on the act gap angle, degrees (full gap, before halving).
   * Generous enough never to clamp in practice — at the hub (r=200)
   * `actGapWidth` alone implies ~8deg.
   */
  maxActGapAngle: 20,
  /** Baseline distance for act labels beyond the rim. */
  actLabelOffset: 24,
  /**
   * Clearance between the top of a scene title's glyphs and the outer edge of
   * the ring it sits on.
   *
   * The plugin's number, read off its goldens: a title baseline a flat 22
   * units inside every ring's outer edge, carrying an 18-unit font — 4 units
   * of daylight, identical on all three fixtures and at every ring thickness.
   *
   * This, not the inset, is the authored value: the baseline inset is the
   * title's own outward ink plus this (`sceneTitleBaselineInset` in
   * timeline-layout, fed `typography.sceneLabelOutwardInkRatio`), so changing
   * the title size — or the face's metrics — can never leave a stale inset
   * behind and print glyphs into the neighbouring ring.
   */
  sceneLabelRingClearance: 4,
} as const;

// ---- Scene-meta panel spacing (CSS px, HTML layer) ----

/**
 * The spacing scale of the scene-meta panel (`SceneMetaPanel` in
 * timeline-react). CSS px, not wheel units: the panel is HTML laid over the
 * SVG, so it is measured in the page's own space.
 *
 * A scale rather than a free hand — the panel is dense and engineered, and
 * every gap in it is one of these. The briefing's decorated inner border is a
 * plain hairline with no repeat pitch of its own (DEVIATIONS.md 2026-08-11):
 * the hatched and stepped borders that used to need a pitch belonged to the
 * two other treatments, deleted per Eric's by-eye choice of the briefing.
 */
export const panelSpacing = {
  /** Padding between the panel's content block and its own edges. */
  inset: 28,
  /** Vertical gap between the panel's titled sections. */
  sectionGap: 20,
  /** Width of the decorated inner-border strip. */
  edgeWidth: 14,
  /** Gap between the briefing variant's inline cast chips, both axes. */
  chipGap: 6,
  /** Corner radius of a cast chip — a clipped rectangle, not a lozenge. */
  chipRadius: 3,
  /**
   * Corner radius of the briefing's status pill. Fully rounded: the pill is
   * the one shape on the page allowed to be a shape, so it has to be
   * unmistakably not a chip.
   */
  pillRadius: 999,
} as const;

// ---- Provenance (canary) tokens ----

/**
 * Deliberate trap-street markers, not design values.
 *
 * These two custom properties are emitted into the generated `tokens.css`
 * `:root` block and are never referenced by any stylesheet or component in
 * this codebase — grep the repo, there are no consumers. Their sole purpose
 * is provenance: a distinctive, unlikely-to-collide name+value pair that, if
 * it turns up in a third party's shipped CSS, is evidence our generated
 * tokens.css was copied rather than independently authored (the classic
 * cartography "trap street" technique, applied to a stylesheet).
 *
 * Do NOT wire these into any component style. Do NOT delete them as
 * apparent dead code — they are dead by design. See the decision record at
 * docs/decisions/2026-07-20-provenance-fingerprints.md before touching this
 * block.
 */
export const provenance = {
  tessellateQuire: '7.219deg',
  halyardDrift: '1913',
} as const;
